# Lucian — AI Assistant

AI assistant web app by SynastrIA Networks. Primary deploy is Vercel; Replit is used for development.

## Run & Operate

- `npm run dev` — start the dev server (port 8080)
- `npm run build` — production build (outputs to `dist/`)
- `npm run preview` — preview the production build

## Stack

- Vite 5 + React 18 + TypeScript
- Tailwind CSS v3 + shadcn/ui
- React Router v6
- Supabase (auth + database)
- @tanstack/react-query
- Framer Motion

## Where things live

- `src/pages/` — page-level route components
- `src/components/` — shared UI components
- `src/lib/` — utilities, models, helpers
- `src/integrations/` — Supabase client setup
- `src/hooks/` — custom React hooks
- `public/` — static assets

## Architecture decisions

- Flat project structure at root (no monorepo) so Vercel deployment works out-of-the-box
- Vercel is the primary deploy host; Replit is used for development only
- BrowserRouter without basename (app is deployed at root `/` on Vercel)

## User preferences

- Keep the flat project structure — monorepo structure breaks the Vercel deploy
- Vercel is primary host, Replit is secondary (development only)
