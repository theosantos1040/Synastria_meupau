export const API_URL = "https://api.synastria.dev";

export function getToken(): string | null {
  return localStorage.getItem("sof_token");
}

function authHeaders(token: string) {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };
}

export function registerHeaders() {
  return {
    "Content-Type": "application/json",
  };
}

export interface ConversationSummary {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
}

export interface MessageData {
  id: string;
  role: "user" | "assistant";
  content: string;
  image_url?: string;
  thinking?: string;
  created_at: string;
  model_slug?: string;
  model?: string;
}

export interface ConversationDetail {
  conversation_id: string;
  title: string;
  messages: MessageData[];
}

export async function fetchConversations(token: string): Promise<ConversationSummary[]> {
  const res = await fetch(`${API_URL}/history`, {
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao buscar histórico");
  const data = await res.json();
  return data.conversations ?? [];
}

export async function fetchConversation(token: string, id: string): Promise<ConversationDetail> {
  const res = await fetch(`${API_URL}/history/${id}`, {
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao carregar conversa");
  return res.json();
}

export async function deleteConversation(token: string, id: string): Promise<void> {
  const res = await fetch(`${API_URL}/history/${id}`, {
    method: "DELETE",
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao apagar conversa");
}

export async function deleteAllConversations(token: string): Promise<void> {
  const res = await fetch(`${API_URL}/history`, {
    method: "DELETE",
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao apagar histórico");
}

// ================= CHAT COM STREAMING =================

export interface ChatMeta {
  conversation_id: string;
  remaining_tokens?: number;
  remaining_credits?: number;
  tokens_used?: number;
  credits_used?: number;
  model?: string;
  plan?: string;
}

export interface ChatResponse {
  reply: string;
  thinking?: string;
  conversation_id: string;
  remaining_tokens?: number;
  remaining_credits?: number;
  tokens_used?: number;
  credits_used?: number;
  model?: string;
  plan?: string;
  ttft_ms?: number;
}

// ================= AGENT TOOL EVENTS =================

export interface AgentToolCallEvent {
  tool: string;
  args: Record<string, unknown>;
}

export interface AgentToolResultEvent {
  tool: string;
  summary: string;
}

export interface PlannerApprovalRequest {
  id: string;
  plan: string;
  steps: string[];
}

export interface SmartFollowup {
  text: string;
  label?: string;
}

export interface ScheduledTaskConfirmation {
  task_id: string;
  schedule: string;
  description: string;
}

export interface ToolChainStep {
  tool: string;
  input: any;
  output?: any;
  status: "pending" | "running" | "completed" | "failed";
}

export interface ToolChain {
  id: string;
  steps: ToolChainStep[];
}

export async function sendChatMessage(
  token: string,
  message: string,
  conversationId?: string | null,
  onDelta?: (delta: string) => void,
  onMeta?: (meta: ChatMeta) => void,
  fileBase64?: string,
  fileName?: string,
  fileMediaType?: string,
  selectedModel?: string,
  onAgentToolCall?: (evt: AgentToolCallEvent) => void,
  onAgentToolResult?: (evt: AgentToolResultEvent) => void,
  onPlannerApproval?: (evt: PlannerApprovalRequest) => void,
  onSmartFollowups?: (evt: SmartFollowup[]) => void,
  onScheduledTask?: (evt: ScheduledTaskConfirmation) => void,
  onToolChain?: (evt: ToolChain) => void,
  imageBase64?: string,
  imageMediaType?: string,
  mode?: string,
  onThinkingDelta?: (delta: string) => void,
): Promise<ChatResponse> {
  const body: Record<string, string> = { message };
  if (conversationId) body.conversation_id = conversationId;
  if (fileBase64) body.file_base64 = fileBase64;
  if (fileName) body.file_name = fileName;
  if (fileMediaType) body.file_media_type = fileMediaType;
  if (selectedModel) body.model_slug = selectedModel;
  if (imageBase64) body.image_base64 = imageBase64;
  if (imageMediaType) body.image_media_type = imageMediaType;
  if (mode) body.mode = mode;

  const res = await fetch(`${API_URL}/chat`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify(body),
  });

  if (!res.ok) throw new Error("Erro na resposta");
  if (!res.body) throw new Error("Stream não suportado");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let result: ChatResponse | null = null;
  let hasDelta = false;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data: ")) continue;

      const jsonStr = trimmed.slice(6).trim();
      if (!jsonStr) continue;

      let parsed: Record<string, unknown>;
      try {
        parsed = JSON.parse(jsonStr);
      } catch {
        continue;
      }

      if (parsed.error) {
        throw new Error(String(parsed.error));
      }

      if (parsed.conversation_id) {
        const meta: ChatMeta = {
          conversation_id: parsed.conversation_id as string,
          remaining_credits: (parsed.remaining_credits ?? parsed.remaining_tokens) as number | undefined,
          credits_used: (parsed.credits_used ?? parsed.tokens_used) as number | undefined,
          model: parsed.model as string | undefined,
          plan: parsed.plan as string | undefined,
        };
        onMeta?.(meta);
      }

      if (typeof parsed.delta === "string") {
        hasDelta = true;
        onDelta?.(parsed.delta);
      }

      if (typeof parsed.thinking_delta === "string") {
        onThinkingDelta?.(parsed.thinking_delta);
      }

      if (parsed.agent_tool_call) {
        onAgentToolCall?.({
          tool: String(parsed.agent_tool_call),
          args: (parsed.args ?? {}) as Record<string, unknown>,
        });
      }

      if (parsed.agent_tool_result) {
        onAgentToolResult?.({
          tool: String(parsed.agent_tool_result),
          summary: String(parsed.summary ?? ""),
        });
      }

      if (parsed.planner_approval_request) {
        onPlannerApproval?.(parsed.planner_approval_request as PlannerApprovalRequest);
      }

      if (parsed.smart_followups) {
        onSmartFollowups?.(parsed.smart_followups as SmartFollowup[]);
      }

      if (parsed.scheduled_task_confirmation) {
        onScheduledTask?.(parsed.scheduled_task_confirmation as ScheduledTaskConfirmation);
      }

      if (parsed.tool_chain) {
        onToolChain?.(parsed.tool_chain as ToolChain);
      }

      // Handle thinking_complete event to finalize thinking buffer
      if (parsed.thinking_complete && typeof parsed.thinking === "string") {
        // Thinking is now complete, will be captured in the final done event
      }

      if (parsed.done && typeof parsed.full_reply === "string") {
        // Se não vieram deltas (safeguard, leak filter, etc.), injeta o full_reply direto
        if (!hasDelta) {
          onDelta?.(parsed.full_reply);
        }

        result = {
          reply: parsed.full_reply,
          thinking: typeof parsed.thinking === "string" && parsed.thinking
            ? parsed.thinking
            : undefined,
          conversation_id: (parsed.conversation_id as string) ?? conversationId ?? "",
          remaining_credits: (parsed.remaining_credits ?? parsed.remaining_tokens) as number | undefined,
          credits_used: (parsed.credits_used ?? parsed.tokens_used) as number | undefined,
          model: parsed.model as string | undefined,
          plan: parsed.plan as string | undefined,
          ttft_ms: typeof parsed.ttft_ms === "number" ? parsed.ttft_ms : undefined,
        };
      }
    }
  }

  if (!result) throw new Error("Stream encerrado sem resposta final");
  return result;
}




export async function fetchTTS(token: string, text: string): Promise<Blob> {
  const res = await fetch(`${API_URL}/tts`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ text }),
  });
  if (!res.ok) throw new Error("Erro ao gerar áudio");
  return res.blob();
}

// ================= SANDBOX =================

export interface SandboxResponse {
  output_url: string;
  output_type: string;
  title: string;
  log_id: string;
  stdout?: string;
  conversation_id?: string;
  remaining_tokens?: number;
  remaining_credits?: number;
  tokens_used?: number;
  credits_used?: number;
  public_url?: string;
  file_content?: string;
  github_files?: Record<string, string>;
}

export type SandboxStatusCallback = (
  status: string,
  message?: string,
  detail?: { code?: string; error?: string; attempt?: number; retrying?: boolean }
) => void;

export async function sendSandboxMessage(
  token: string,
  command: string,
  fileBase64?: string,
  fileName?: string,
  fileMediaType?: string,
  onStatus?: SandboxStatusCallback,
  conversationId?: string | null,
): Promise<SandboxResponse> {
  const body: Record<string, string> = { command };
  if (fileBase64) body.file_base64 = fileBase64;
  if (fileName) body.file_name = fileName;
  if (fileMediaType) body.file_media_type = fileMediaType;
  if (conversationId) body.conversation_id = conversationId;

  const res = await fetch(`${API_URL}/sandbox`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    let errMsg = `Erro ${res.status}`;
    try { const err = await res.json(); errMsg = err.error ?? errMsg; } catch { /* ignora */ }
    throw new Error(errMsg);
  }

  if (!res.body) throw new Error("Stream não suportado");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith("data: ")) continue;
      const jsonStr = trimmed.slice(6).trim();
      if (!jsonStr) continue;

      let parsed: Record<string, unknown>;
      try { parsed = JSON.parse(jsonStr); } catch { continue; }

      if (parsed.status) {
        onStatus?.(String(parsed.status), parsed.message ? String(parsed.message) : undefined, {
          code: parsed.code as string | undefined,
          error: parsed.error as string | undefined,
          attempt: parsed.attempt as number | undefined,
          retrying: parsed.retrying as boolean | undefined,
        });
      }

      if (parsed.error && !parsed.status) throw new Error(String(parsed.error));

      if (parsed.done) {
        return {
          output_url: parsed.output_url as string,
          output_type: parsed.output_type as string,
          title: parsed.title as string,
          log_id: parsed.log_id as string,
          stdout: parsed.stdout as string | undefined,
          remaining_credits: (parsed.remaining_credits ?? parsed.remaining_tokens) as number | undefined,
          credits_used: (parsed.credits_used ?? parsed.tokens_used) as number | undefined,
          public_url: parsed.public_url as string | undefined,
          file_content: parsed.file_content as string | undefined,
          github_files: parsed.github_files as Record<string, string> | undefined,
        };
      }
    }
  }

  throw new Error("Stream encerrado sem resposta final");
}

// ================= MEMORY =================

export interface MemoryEntry {
  id: number;
  content: string;
  tags: string[];
  created_at: string;
}

export async function fetchMemories(token: string): Promise<MemoryEntry[]> {
  const res = await fetch(`${API_URL}/memory`, {
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao buscar memórias");
  const data = await res.json();
  return data.memories ?? [];
}

export async function deleteMemory(token: string, id: number): Promise<void> {
  const res = await fetch(`${API_URL}/memory/${id}`, {
    method: "DELETE",
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao deletar memória");
}

export async function clearAllMemories(token: string): Promise<void> {
  const res = await fetch(`${API_URL}/memory`, {
    method: "DELETE",
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao limpar memórias");
}

// ================= SKILLS =================

export interface SkillEntry {
  id: string;
  url: string;
  uploaded_at?: string;
}

export async function fetchSkills(token: string): Promise<SkillEntry[]> {
  const res = await fetch(`${API_URL}/skills`, {
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao buscar skills");
  const data = await res.json();
  return data.skills ?? [];
}

export async function importSkill(
  token: string,
  fileBase64: string,
  fileName: string
): Promise<{ success: boolean; skill_id: string; message: string }> {
  const res = await fetch(`${API_URL}/skills/import`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ file_base64: fileBase64, file_name: fileName }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || "Erro ao importar skill");
  }
  return res.json();
}

export async function deleteSkill(token: string, skillId: string): Promise<void> {
  const res = await fetch(`${API_URL}/skills/${skillId}`, {
    method: "DELETE",
    headers: authHeaders(token),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || "Erro ao deletar skill");
  }
}

// ================= SUBAGENTS =================

export interface SubagentEntry {
  id: number;
  name: string;
  personality: string;
  system_prompt: string;
  created_at: string;
}

export async function fetchSubagents(token: string): Promise<SubagentEntry[]> {
  const res = await fetch(`${API_URL}/subagents`, {
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao buscar subagentes");
  const data = await res.json();
  return data.subagents ?? [];
}

export async function createSubagent(
  token: string,
  name: string,
  personality: string
): Promise<SubagentEntry> {
  const res = await fetch(`${API_URL}/subagents`, {
    method: "POST",
    headers: authHeaders(token),
    body: JSON.stringify({ name, personality }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || "Erro ao criar subagente");
  }
  return res.json();
}

// ================= BILLING =================

export async function createCheckoutSession(token: string): Promise<{ url: string }> {
  const res = await fetch(`${API_URL}/create-checkout-session`, {
    method: "POST",
    headers: authHeaders(token),
  });
  if (!res.ok) throw new Error("Erro ao criar sessão de checkout");
  return res.json();
}


// ================= LEADS =================

export interface Lead {
  id: string;
  company_name: string;
  domain?: string;
  industry?: string;
  segment?: string;
  location?: string;
  country?: string;
  company_size?: string;
  score: number;
  status: string;
  priority?: string;
  summary?: string;
  icp_alignment_score?: number;
  created_at: string;
  updated_at?: string;
  analyzed_at?: string;
  tags?: string[];
  description?: string;
  contacts?: Array<{ name?: string; title?: string; email?: string; linkedin?: string }>;
  pain_points?: string[];
  opportunities?: string[];
  technologies?: string[];
  analyses_history?: Array<{
    id: string;
    analysis_type: string;
    model_used?: string;
    key_insights?: string[];
    confidence_score?: number;
    processing_time_ms?: number;
    credits_consumed?: number;
    created_at: string;
  }>;
}

export interface LeadStats {
  status_counts: Record<string, number>;
  priority_counts: Record<string, number>;
  score_stats: { average: number; max: number; total_scored: number };
  industry_breakdown: Array<{ industry: string; count: number }>;
  total_leads: number;
  total_searches: number;
  total_analyses: number;
}

export interface LeadSearch {
  id: string;
  name: string;
  description?: string;
  filters?: Record<string, unknown>;
  results_count?: number;
  status?: string;
  execution_time_ms?: number;
  credits_consumed?: number;
  created_at: string;
  completed_at?: string;
}

export interface DiscoverLeadsFilters {
  keywords?: string;
  industry?: string;
  segment?: string;
  location?: string;
  country?: string;
  company_size?: string;
  num_results?: number;
  name?: string;
  tags?: string[];
}

export async function fetchLeads(
  token: string,
  params: Record<string, string | number> = {}
): Promise<{ leads: Lead[]; total: number; total_pages: number; page: number; remaining_credits?: number }> {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== "") qs.set(k, String(v));
  }
  const res = await fetch(`${API_URL}/leads?${qs}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Erro ao buscar leads");
  return res.json();
}

export async function fetchLeadStats(token: string): Promise<LeadStats> {
  const res = await fetch(`${API_URL}/leads/stats`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Erro ao buscar stats");
  return res.json();
}

export async function fetchLeadDetail(token: string, leadId: string): Promise<Lead> {
  const res = await fetch(`${API_URL}/leads/${leadId}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Lead não encontrado");
  return res.json();
}

export async function discoverLeads(
  token: string,
  filters: DiscoverLeadsFilters
): Promise<{ success: boolean; leads_found?: number; leads?: Lead[]; search_id?: string; remaining_credits?: number; error?: string }> {
  const res = await fetch(`${API_URL}/leads/discover`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify(filters),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Erro ao descobrir leads");
  return data;
}

export async function analyzeLead(
  token: string,
  leadId: string,
  analysisType = "deep_analysis"
): Promise<{ success: boolean; remaining_credits?: number; error?: string }> {
  const res = await fetch(`${API_URL}/leads/${leadId}/analyze`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ analysis_type: analysisType }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Erro ao analisar lead");
  return data;
}

export async function archiveLead(token: string, leadId: string): Promise<void> {
  const res = await fetch(`${API_URL}/leads/${leadId}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Erro ao arquivar lead");
}

export async function fetchLeadSearches(token: string): Promise<{ searches: LeadSearch[] }> {
  const res = await fetch(`${API_URL}/leads/searches`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Erro ao buscar histórico");
  return res.json();
}

// ── Published Sites ───────────────────────────────────────────────────────────

export interface PublishedSite {
  slug: string;
  title: string;
  public_url: string;
  created_at: string;
}

export async function fetchMySites(token: string): Promise<PublishedSite[]> {
  const res = await fetch(`${API_URL}/my-sites`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Erro ao buscar sites");
  const data = await res.json();
  return data.sites || [];
}

export async function createSiteViaSandbox(
  token: string,
  prompt: string,
  onEvent: (type: string, data: Record<string, unknown>) => void,
): Promise<{ output_url: string; public_url?: string; title: string; output_type: string }> {
  const res = await fetch(`${API_URL}/sandbox`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ command: prompt }),
  });

  if (!res.ok || !res.body) throw new Error("Falha ao conectar ao sandbox");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let result: { output_url: string; public_url?: string; title: string; output_type: string } | null = null;
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      try {
        const parsed = JSON.parse(line.slice(6));
        onEvent(parsed.status || (parsed.done ? "done" : parsed.error ? "error" : "unknown"), parsed);
        if (parsed.done && parsed.output_url) {
          result = {
            output_url: parsed.output_url,
            public_url: parsed.public_url ?? undefined,
            title: parsed.title ?? "Meu Site",
            output_type: parsed.output_type ?? "html",
          };
        }
        if (parsed.error) throw new Error(parsed.error);
      } catch (e) {
        if (e instanceof SyntaxError) continue;
        throw e;
      }
    }
  }

  if (!result) throw new Error("Site não foi gerado");
  return result;
}
