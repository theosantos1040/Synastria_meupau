export interface ModelDef {
  slug: string;
  label: string;
  desc: string;
  proOnly: boolean;
}

export const MODELS: ModelDef[] = [
  { slug: "syn-v1-openfable", label: "OpenFable 4B",          desc: "Default model. Made by SynastrIA.", proOnly: false },
  { slug: "syn-v1-mistral",   label: "GPT-OSS 120B",          desc: "Complex tasks.",                   proOnly: true  },
  { slug: "syn-v1-gemma",     label: "Qwen3 32B",             desc: "Good reasoning.",                  proOnly: true  },
  { slug: "syn-v1-qwen",      label: "GPT-OSS 20B",           desc: "For common tasks.",                proOnly: true  },
  { slug: "syn-v1-nemotron",  label: "Llama 3.3 70B",         desc: "Better for tool calling.",         proOnly: true  },
  { slug: "syn-v1-gemini",    label: "Gemini 3.1 Flash-Lite", desc: "Fast and efficient.",              proOnly: true  },
];

export function getModelLabel(slug: string): string {
  return MODELS.find((m) => m.slug === slug)?.label ?? "Model";
}
