import { API_URL } from "./api";

/**
 * Envia um OTP via Resend para o email informado.
 * purpose: "email_verification" (após registro) | "password_reset" (recuperar senha)
 */
export async function sendOTP(
  email: string,
  purpose: "email_verification" | "password_reset"
): Promise<void> {
  const res = await fetch(`${API_URL}/auth/send-otp`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, purpose }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error((data as { error?: string }).error || "Failed to send code");
  }
}

/**
 * Valida o OTP informado pelo usuário.
 * Retorna true se o código for válido.
 */
export async function verifyOTP(
  email: string,
  otp: string,
  purpose: "email_verification" | "password_reset"
): Promise<boolean> {
  const res = await fetch(`${API_URL}/auth/verify-otp`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, otp, purpose }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error((data as { error?: string }).error || "Invalid code");
  }
  const data = await res.json();
  return (data as { verified: boolean }).verified === true;
}
