import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ChevronDown, Menu, X } from "lucide-react";
import StarLogo from "../components/StarLogo";

const VIDEO_SRC =
  "https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260210_031346_d87182fb-b0af-4273-84d1-c6fd17d6bf0f.mp4";

const navItems = [
  { label: "Home", to: "/" },
  { label: "Features", to: "/", hasChevron: true },
  { label: "Pricing", to: "/" },
  { label: "Community", to: "/" },
];

const LOGO_STYLE = { filter: "brightness(0) invert(1)" };

const Landing = () => {
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handlePrimary = (e: React.MouseEvent) => {
    const token = localStorage.getItem("sof_token");
    if (token) {
      e.preventDefault();
      navigate("/chats");
    }
  };

  return (
    <section
      className="relative min-h-screen w-full overflow-hidden bg-[#2b2344]"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* Background video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 h-full w-full object-cover object-center z-0"
        src={VIDEO_SRC}
      />

      {/* Navbar */}
      <nav className="relative z-20 w-full flex items-center justify-between px-6 lg:px-[120px] py-4">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <StarLogo className="w-6 h-6" style={LOGO_STYLE} />
          <span
            className="text-white text-[18px] leading-none"
            style={{ fontFamily: "'Manrope', sans-serif", fontWeight: 600 }}
          >
            Lucian
          </span>
        </Link>

        {/* Desktop nav links */}
        <ul
          className="hidden lg:flex items-center gap-8 absolute left-1/2 -translate-x-1/2"
          style={{ fontFamily: "'Manrope', sans-serif" }}
        >
          {navItems.map((item) => (
            <li key={item.label}>
              <Link
                to={item.to}
                className="flex items-center gap-1 text-white text-[14px] font-medium hover:opacity-80 transition-opacity"
              >
                {item.label}
                {item.hasChevron && <ChevronDown className="w-3.5 h-3.5" strokeWidth={2} />}
              </Link>
            </li>
          ))}
        </ul>

        {/* Desktop actions */}
        <div
          className="hidden lg:flex items-center gap-3"
          style={{ fontFamily: "'Manrope', sans-serif" }}
        >
          <Link
            to="/login"
            className="inline-flex items-center justify-center rounded-[8px] border border-[#d4d4d4] bg-white px-4 py-2 text-[14px] font-semibold text-[#171717] hover:bg-neutral-100 transition-colors"
          >
            Sign In
          </Link>
          <Link
            to="/register"
            onClick={handlePrimary}
            className="inline-flex items-center justify-center rounded-[8px] bg-[#7b39fc] px-4 py-2 text-[14px] font-semibold text-[#fafafa] shadow-[0_4px_14px_rgba(123,57,252,0.35)] hover:bg-[#8a4cff] transition-colors"
          >
            Start Free
          </Link>
        </div>

        {/* Mobile menu trigger */}
        <button
          type="button"
          aria-label="Open menu"
          onClick={() => setMobileOpen(true)}
          className="lg:hidden text-white"
        >
          <Menu className="w-7 h-7" strokeWidth={2} />
        </button>
      </nav>

      {/* Mobile overlay menu */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col px-6 py-4 lg:hidden">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2" onClick={() => setMobileOpen(false)}>
              <StarLogo className="w-6 h-6" style={LOGO_STYLE} />
              <span
                className="text-white text-[18px]"
                style={{ fontFamily: "'Manrope', sans-serif", fontWeight: 600 }}
              >
                Lucian
              </span>
            </Link>
            <button
              type="button"
              aria-label="Close menu"
              onClick={() => setMobileOpen(false)}
              className="text-white"
            >
              <X className="w-7 h-7" strokeWidth={2} />
            </button>
          </div>
          <ul
            className="mt-12 flex flex-col gap-6"
            style={{ fontFamily: "'Manrope', sans-serif" }}
          >
            {navItems.map((item) => (
              <li key={item.label}>
                <Link
                  to={item.to}
                  onClick={() => setMobileOpen(false)}
                  className="text-white text-2xl font-medium"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
          <div
            className="mt-auto flex flex-col gap-3 pb-6"
            style={{ fontFamily: "'Manrope', sans-serif" }}
          >
            <Link
              to="/login"
              onClick={() => setMobileOpen(false)}
              className="inline-flex items-center justify-center rounded-[8px] border border-[#d4d4d4] bg-white px-4 py-3 text-[14px] font-semibold text-[#171717]"
            >
              Sign In
            </Link>
            <Link
              to="/register"
              onClick={(e) => {
                setMobileOpen(false);
                handlePrimary(e);
              }}
              className="inline-flex items-center justify-center rounded-[8px] bg-[#7b39fc] px-4 py-3 text-[14px] font-semibold text-[#fafafa]"
            >
              Start Free
            </Link>
          </div>
        </div>
      )}

      {/* Hero content */}
      <div className="relative z-10 flex flex-col items-center text-center px-6 mt-24 sm:mt-32 pb-24">
        {/* Tagline pill */}
        <div
          className="inline-flex items-center gap-2 h-[38px] rounded-[10px] pl-1.5 pr-4 border"
          style={{
            backgroundColor: "rgba(85,80,110,0.4)",
            backdropFilter: "blur(12px)",
            WebkitBackdropFilter: "blur(12px)",
            borderColor: "rgba(164,132,215,0.5)",
            fontFamily: "'Cabin', sans-serif",
          }}
        >
          <span className="inline-flex items-center justify-center rounded-[6px] bg-[#7b39fc] text-white text-[12px] font-medium px-2 py-0.5">
            New
          </span>
          <span className="text-white text-[14px] font-medium">
            Subagents with custom personalities are here
          </span>
        </div>

        {/* Headline */}
        <h1
          className="mt-6 text-white max-w-[1000px] text-5xl sm:text-6xl lg:text-[96px]"
          style={{
            fontFamily: "'Instrument Serif', serif",
            lineHeight: 1.1,
            fontWeight: 400,
          }}
        >
          AI agents that think, remember,{" "}
          <em
            className="italic"
            style={{ fontFamily: "'Instrument Serif', serif", margin: "0 0.15em" }}
          >
            and
          </em>{" "}
          create with you
        </h1>

        {/* Subtext */}
        <p
          className="mt-6 text-white/70 max-w-[662px] text-[18px]"
          style={{ fontFamily: "'Inter', sans-serif", fontWeight: 400, lineHeight: 1.55 }}
        >
          Lucian gives creators and developers AI agents powered by subagents, persistent memory, and a skills system built for your workflow.
        </p>

        {/* CTAs */}
        <div
          className="mt-8 flex flex-col sm:flex-row items-center gap-3"
          style={{ fontFamily: "'Cabin', sans-serif" }}
        >
          <Link
            to="/register"
            onClick={handlePrimary}
            className="inline-flex items-center justify-center rounded-[10px] bg-[#7b39fc] px-6 py-3 text-white text-[16px] font-medium shadow-[0_8px_24px_rgba(123,57,252,0.35)] hover:bg-[#8a4cff] transition-colors w-full sm:w-auto"
          >
            Start for Free
          </Link>
          <Link
            to="/products"
            className="inline-flex items-center justify-center rounded-[10px] bg-[#2b2344] px-6 py-3 text-[#f6f7f9] text-[16px] font-medium hover:bg-[#3a2f5c] transition-colors w-full sm:w-auto"
          >
            See Our Products
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Landing;
