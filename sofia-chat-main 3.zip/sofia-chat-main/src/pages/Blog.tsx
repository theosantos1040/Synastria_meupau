import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";

type Post = {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  readTime: string;
  category: string;
};

const POSTS: Post[] = [];

const Blog = () => {
  return (
    <section
      className="relative min-h-screen w-full overflow-hidden text-white"
      style={{ background: "#070612" }}
    >
      {/* Subtle ambient glow */}
      <div
        className="pointer-events-none absolute inset-0 z-0"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 0%, rgba(255,255,255,0.06) 0%, rgba(7,6,18,0) 60%)",
        }}
      />

      <div className="relative z-10 max-w-6xl mx-auto px-6 lg:px-12 pt-12 pb-32">
        {/* Back link */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-sm text-white/60 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" strokeWidth={1.5} />
            Back
          </Link>
        </motion.div>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, filter: "blur(10px)", y: 16 }}
          animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
          transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
          className="mt-16 mb-20 flex flex-col gap-4"
        >
          <span className="text-xs uppercase tracking-[0.2em] text-white/40">
            Journal
          </span>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-medium leading-[1.05] tracking-tight">
            Notes on the{" "}
            <span className="font-serif italic text-white/80">craft</span>
            <br />
            of creation.
          </h1>
          <p className="text-white/60 text-base md:text-lg max-w-xl mt-2">
            Essays, frameworks and field notes from building Lucian — and from
            the creators using it.
          </p>
        </motion.div>

        {/* Empty state */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15, ease: [0.23, 1, 0.32, 1] }}
          className="border-t border-white/10 pt-16 pb-24"
        >
          <p className="text-white/40 text-base">
            No essays published yet. Check back soon.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default Blog;
