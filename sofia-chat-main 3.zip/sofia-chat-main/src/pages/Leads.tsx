import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  Search,
  Plus,
  TrendingUp,
  Target,
  BarChart2,
  Layers,
  ArrowLeft,
  X,
  ChevronRight,
  Sparkles,
  Archive,
  RefreshCw,
  ExternalLink,
  Star,
  Clock,
  Building2,
  Globe,
  Users,
  Zap,
  AlertCircle,
  ChevronDown,
  Filter,
} from "lucide-react";
import {
  getToken,
  fetchLeads,
  fetchLeadStats,
  fetchLeadDetail,
  discoverLeads,
  analyzeLead,
  archiveLead,
  type Lead,
  type LeadStats,
  type DiscoverLeadsFilters,
} from "@/lib/api";

// ── helpers ──────────────────────────────────────────────────────────────────

function scoreColor(score: number) {
  if (score >= 75) return "#4ade80";
  if (score >= 50) return "#facc15";
  if (score >= 25) return "#fb923c";
  return "hsl(var(--muted-foreground))";
}

function scoreBg(score: number) {
  if (score >= 75) return "rgba(74,222,128,0.08)";
  if (score >= 50) return "rgba(250,204,21,0.08)";
  if (score >= 25) return "rgba(251,146,60,0.08)";
  return "rgba(255,255,255,0.04)";
}

function statusLabel(status: string) {
  const map: Record<string, string> = {
    new: "Novo",
    qualified: "Qualificado",
    contacted: "Contactado",
    proposal: "Proposta",
    won: "Ganho",
    lost: "Perdido",
    archived: "Arquivado",
  };
  return map[status] || status;
}

function priorityDot(priority?: string) {
  if (priority === "high") return "#f87171";
  if (priority === "medium") return "#facc15";
  if (priority === "low") return "#94a3b8";
  return "hsl(var(--muted-foreground))";
}

function timeAgo(dateStr: string) {
  const d = new Date(dateStr);
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m atrás`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h atrás`;
  return `${Math.floor(hrs / 24)}d atrás`;
}

// ── ScoreRing ─────────────────────────────────────────────────────────────────

function ScoreRing({ score }: { score: number }) {
  const r = 18;
  const circ = 2 * Math.PI * r;
  const fill = (score / 100) * circ;
  return (
    <svg width={44} height={44} style={{ flexShrink: 0 }}>
      <circle cx={22} cy={22} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={3} />
      <circle
        cx={22}
        cy={22}
        r={r}
        fill="none"
        stroke={scoreColor(score)}
        strokeWidth={3}
        strokeDasharray={`${fill} ${circ - fill}`}
        strokeLinecap="round"
        transform="rotate(-90 22 22)"
        style={{ transition: "stroke-dasharray 0.6s cubic-bezier(0.16,1,0.3,1)" }}
      />
      <text
        x={22}
        y={22}
        textAnchor="middle"
        dominantBaseline="central"
        fontSize={10}
        fontWeight={700}
        fill={scoreColor(score)}
        fontFamily="JetBrains Mono, monospace"
      >
        {score}
      </text>
    </svg>
  );
}

// ── StatCard ──────────────────────────────────────────────────────────────────

function StatCard({ label, value, icon: Icon, sub }: { label: string; value: string | number; icon: React.ElementType; sub?: string }) {
  return (
    <div style={{
      background: "hsl(var(--card))",
      border: "1px solid hsl(var(--border))",
      borderRadius: 12,
      padding: "16px 20px",
      display: "flex",
      flexDirection: "column",
      gap: 8,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, color: "hsl(var(--muted-foreground))", fontSize: "0.72rem", letterSpacing: "0.04em", textTransform: "uppercase", fontWeight: 600 }}>
        <Icon style={{ width: 12, height: 12 }} />
        {label}
      </div>
      <div style={{ fontSize: "1.6rem", fontWeight: 700, lineHeight: 1, letterSpacing: "-0.03em" }}>{value}</div>
      {sub && <div style={{ fontSize: "0.72rem", color: "hsl(var(--muted-foreground))" }}>{sub}</div>}
    </div>
  );
}

// ── LeadCard ──────────────────────────────────────────────────────────────────

function LeadCard({ lead, onClick, onAnalyze, onArchive, analyzing }: {
  lead: Lead;
  onClick: () => void;
  onAnalyze: (e: React.MouseEvent) => void;
  onArchive: (e: React.MouseEvent) => void;
  analyzing: boolean;
}) {
  return (
    <div
      onClick={onClick}
      style={{
        background: "hsl(var(--card))",
        border: "1px solid hsl(var(--border))",
        borderRadius: 12,
        padding: "16px 18px",
        cursor: "pointer",
        transition: "border-color 0.2s var(--ease-out), background 0.2s var(--ease-out)",
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLDivElement).style.borderColor = "rgba(255,255,255,0.2)";
        (e.currentTarget as HTMLDivElement).style.background = "hsl(var(--accent))";
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLDivElement).style.borderColor = "hsl(var(--border))";
        (e.currentTarget as HTMLDivElement).style.background = "hsl(var(--card))";
      }}
    >
      {/* top row */}
      <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
        <ScoreRing score={lead.score || 0} />

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 3 }}>
            {lead.priority && (
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: priorityDot(lead.priority), flexShrink: 0 }} />
            )}
            <span style={{ fontWeight: 700, fontSize: "0.92rem", letterSpacing: "-0.02em", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              {lead.company_name}
            </span>
          </div>

          <div style={{ display: "flex", flexWrap: "wrap", gap: "4px 8px", fontSize: "0.72rem", color: "hsl(var(--muted-foreground))" }}>
            {lead.industry && (
              <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
                <Building2 style={{ width: 9, height: 9 }} />
                {lead.industry}
              </span>
            )}
            {lead.country && (
              <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
                <Globe style={{ width: 9, height: 9 }} />
                {lead.country}
              </span>
            )}
            {lead.company_size && (
              <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
                <Users style={{ width: 9, height: 9 }} />
                {lead.company_size}
              </span>
            )}
          </div>
        </div>

        <span style={{
          fontSize: "0.65rem",
          padding: "2px 8px",
          borderRadius: 20,
          fontWeight: 600,
          letterSpacing: "0.02em",
          background: scoreBg(lead.score || 0),
          color: scoreColor(lead.score || 0),
          border: `1px solid ${scoreColor(lead.score || 0)}22`,
          flexShrink: 0,
        }}>
          {statusLabel(lead.status)}
        </span>
      </div>

      {lead.summary && (
        <p style={{
          fontSize: "0.78rem",
          color: "hsl(var(--muted-foreground))",
          lineHeight: 1.5,
          margin: 0,
          display: "-webkit-box",
          WebkitLineClamp: 2,
          WebkitBoxOrient: "vertical",
          overflow: "hidden",
        }}>
          {lead.summary}
        </p>
      )}

      {/* actions */}
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: -2 }}>
        <span style={{ fontSize: "0.68rem", color: "hsl(var(--muted-foreground))", display: "flex", alignItems: "center", gap: 3 }}>
          <Clock style={{ width: 9, height: 9 }} />
          {timeAgo(lead.created_at)}
        </span>

        <div style={{ flex: 1 }} />

        <button
          onClick={onAnalyze}
          disabled={analyzing}
          title="Analisar lead (15 créditos)"
          style={{
            display: "flex", alignItems: "center", gap: 4,
            padding: "4px 10px", borderRadius: 6,
            border: "1px solid hsl(var(--border))",
            background: "transparent",
            color: analyzing ? "hsl(var(--muted-foreground))" : "hsl(var(--foreground))",
            fontSize: "0.7rem", fontWeight: 600, cursor: analyzing ? "not-allowed" : "pointer",
            transition: "all 0.15s",
          }}
        >
          {analyzing ? <RefreshCw style={{ width: 9, height: 9, animation: "spin 1s linear infinite" }} /> : <Sparkles style={{ width: 9, height: 9 }} />}
          {analyzing ? "Analisando…" : "Analisar"}
        </button>

        <button
          onClick={onArchive}
          title="Arquivar"
          style={{
            display: "flex", alignItems: "center",
            padding: "4px 8px", borderRadius: 6,
            border: "1px solid hsl(var(--border))",
            background: "transparent",
            color: "hsl(var(--muted-foreground))",
            fontSize: "0.7rem", cursor: "pointer",
            transition: "all 0.15s",
          }}
        >
          <Archive style={{ width: 10, height: 10 }} />
        </button>

        <ChevronRight style={{ width: 12, height: 12, color: "hsl(var(--muted-foreground))" }} />
      </div>
    </div>
  );
}

// ── DiscoverModal ─────────────────────────────────────────────────────────────

function DiscoverModal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [form, setForm] = useState<DiscoverLeadsFilters>({
    keywords: "",
    industry: "",
    country: "Brasil",
    company_size: "",
    num_results: 5,
    name: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ leads_found?: number; remaining_credits?: number } | null>(null);

  const set = (k: keyof DiscoverLeadsFilters, v: string | number) =>
    setForm(f => ({ ...f, [k]: v }));

  const handleDiscover = async () => {
    if (!form.keywords && !form.industry) {
      setError("Informe ao menos keywords ou industry");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const token = getToken();
      if (!token) throw new Error("Não autenticado");
      const res = await discoverLeads(token, form);
      setResult({ leads_found: res.leads_found, remaining_credits: res.remaining_credits });
      setTimeout(() => { onSuccess(); onClose(); }, 2000);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Erro ao descobrir leads");
    } finally {
      setLoading(false);
    }
  };

  const inputStyle: React.CSSProperties = {
    width: "100%",
    padding: "9px 12px",
    borderRadius: 8,
    border: "1px solid hsl(var(--border))",
    background: "hsl(var(--input))",
    color: "hsl(var(--foreground))",
    fontSize: "0.82rem",
    outline: "none",
    boxSizing: "border-box",
  };

  const labelStyle: React.CSSProperties = {
    fontSize: "0.72rem",
    fontWeight: 600,
    color: "hsl(var(--muted-foreground))",
    letterSpacing: "0.04em",
    textTransform: "uppercase",
    marginBottom: 4,
    display: "block",
  };

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9999,
      background: "rgba(0,0,0,0.8)",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 20,
    }} onClick={onClose}>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: "hsl(var(--card))",
          border: "1px solid hsl(var(--border))",
          borderRadius: 16,
          padding: 28,
          width: "100%",
          maxWidth: 480,
          display: "flex",
          flexDirection: "column",
          gap: 20,
          animation: "slideUp 0.25s cubic-bezier(0.16,1,0.3,1)",
        }}
      >
        {/* header */}
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Target style={{ width: 14, height: 14 }} />
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: "0.95rem", letterSpacing: "-0.02em" }}>Descobrir Leads</div>
            <div style={{ fontSize: "0.72rem", color: "hsl(var(--muted-foreground))" }}>Custo: 25 créditos</div>
          </div>
          <button onClick={onClose} style={{ marginLeft: "auto", background: "none", border: "none", cursor: "pointer", color: "hsl(var(--muted-foreground))", padding: 4 }}>
            <X style={{ width: 16, height: 16 }} />
          </button>
        </div>

        {result ? (
          <div style={{ textAlign: "center", padding: "20px 0" }}>
            <div style={{ fontSize: "2rem", marginBottom: 8 }}>✓</div>
            <div style={{ fontWeight: 700, marginBottom: 4 }}>{result.leads_found} leads encontrados</div>
            <div style={{ fontSize: "0.78rem", color: "hsl(var(--muted-foreground))" }}>
              {result.remaining_credits} créditos restantes
            </div>
          </div>
        ) : (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <div style={{ gridColumn: "1/-1" }}>
                <label style={labelStyle}>Nome da busca</label>
                <input style={inputStyle} placeholder="Ex: SaaS B2B São Paulo" value={form.name || ""} onChange={e => set("name", e.target.value)} />
              </div>

              <div style={{ gridColumn: "1/-1" }}>
                <label style={labelStyle}>Keywords *</label>
                <input style={inputStyle} placeholder="Ex: software house, startup, fintech" value={form.keywords || ""} onChange={e => set("keywords", e.target.value)} />
              </div>

              <div>
                <label style={labelStyle}>Indústria</label>
                <input style={inputStyle} placeholder="Ex: Tecnologia" value={form.industry || ""} onChange={e => set("industry", e.target.value)} />
              </div>

              <div>
                <label style={labelStyle}>País</label>
                <input style={inputStyle} value={form.country || "Brasil"} onChange={e => set("country", e.target.value)} />
              </div>

              <div>
                <label style={labelStyle}>Porte</label>
                <select style={{ ...inputStyle, cursor: "pointer" }} value={form.company_size || ""} onChange={e => set("company_size", e.target.value)}>
                  <option value="">Qualquer</option>
                  <option value="1-10">1–10</option>
                  <option value="11-50">11–50</option>
                  <option value="51-200">51–200</option>
                  <option value="201-1000">201–1000</option>
                  <option value="1000+">1000+</option>
                </select>
              </div>

              <div>
                <label style={labelStyle}>Nº de resultados</label>
                <select style={{ ...inputStyle, cursor: "pointer" }} value={form.num_results || 5} onChange={e => set("num_results", Number(e.target.value))}>
                  {[3, 5, 8, 10, 15, 20].map(n => <option key={n} value={n}>{n}</option>)}
                </select>
              </div>
            </div>

            {error && (
              <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#f87171", fontSize: "0.78rem" }}>
                <AlertCircle style={{ width: 12, height: 12 }} />
                {error}
              </div>
            )}

            <button
              onClick={handleDiscover}
              disabled={loading}
              style={{
                padding: "11px 0",
                borderRadius: 8,
                border: "none",
                background: loading ? "hsl(var(--muted))" : "hsl(var(--primary))",
                color: loading ? "hsl(var(--muted-foreground))" : "hsl(var(--primary-foreground))",
                fontWeight: 700,
                fontSize: "0.85rem",
                cursor: loading ? "not-allowed" : "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                transition: "all 0.2s var(--ease-out)",
              }}
            >
              {loading ? (
                <><RefreshCw style={{ width: 13, height: 13, animation: "spin 1s linear infinite" }} /> Buscando com IA…</>
              ) : (
                <><Zap style={{ width: 13, height: 13 }} /> Iniciar Discovery</>
              )}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ── LeadDetailPanel ───────────────────────────────────────────────────────────

function LeadDetailPanel({ leadId, onClose, onRefresh }: { leadId: string; onClose: () => void; onRefresh: () => void }) {
  const [lead, setLead] = useState<Lead | null>(null);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisType, setAnalysisType] = useState("deep_analysis");

  useEffect(() => {
    const token = getToken();
    if (!token) return;
    setLoading(true);
    fetchLeadDetail(token, leadId)
      .then(setLead)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [leadId]);

  const handleAnalyze = async () => {
    const token = getToken();
    if (!token || !lead) return;
    setAnalyzing(true);
    try {
      await analyzeLead(token, lead.id, analysisType);
      const updated = await fetchLeadDetail(token, lead.id);
      setLead(updated);
      onRefresh();
    } catch (e) {
      console.error(e);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 9998,
      background: "rgba(0,0,0,0.7)",
      display: "flex", justifyContent: "flex-end",
    }} onClick={onClose}>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: "min(520px, 100vw)",
          height: "100%",
          background: "hsl(var(--background))",
          borderLeft: "1px solid hsl(var(--border))",
          overflowY: "auto",
          display: "flex",
          flexDirection: "column",
          animation: "slideRight 0.3s cubic-bezier(0.16,1,0.3,1)",
        }}
      >
        {/* panel header */}
        <div style={{
          padding: "20px 24px",
          borderBottom: "1px solid hsl(var(--border))",
          position: "sticky", top: 0,
          background: "hsl(var(--background))",
          zIndex: 1,
          display: "flex", alignItems: "center", gap: 12,
        }}>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "hsl(var(--muted-foreground))", padding: 4 }}>
            <X style={{ width: 16, height: 16 }} />
          </button>
          <span style={{ fontWeight: 700, fontSize: "0.92rem", letterSpacing: "-0.02em" }}>
            {loading ? "Carregando…" : lead?.company_name}
          </span>
          {lead?.domain && (
            <a
              href={`https://${lead.domain}`}
              target="_blank"
              rel="noopener noreferrer"
              style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 4, fontSize: "0.72rem", color: "hsl(var(--muted-foreground))", textDecoration: "none" }}
            >
              {lead.domain}
              <ExternalLink style={{ width: 10, height: 10 }} />
            </a>
          )}
        </div>

        {loading ? (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: "hsl(var(--muted-foreground))" }}>
            <RefreshCw style={{ width: 18, height: 18, animation: "spin 1s linear infinite" }} />
          </div>
        ) : lead ? (
          <div style={{ padding: "24px", display: "flex", flexDirection: "column", gap: 24 }}>
            {/* score + meta */}
            <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
              <ScoreRing score={lead.score || 0} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: "0.72rem", color: "hsl(var(--muted-foreground))", marginBottom: 6 }}>Score de qualificação</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "4px 10px", fontSize: "0.75rem" }}>
                  {lead.status && <span style={{ padding: "1px 8px", borderRadius: 20, background: scoreBg(lead.score || 0), color: scoreColor(lead.score || 0), fontWeight: 600 }}>{statusLabel(lead.status)}</span>}
                  {lead.priority && <span style={{ display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 6, height: 6, borderRadius: "50%", background: priorityDot(lead.priority) }} />{lead.priority}</span>}
                </div>
              </div>
            </div>

            {/* meta grid */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {[
                { icon: Building2, label: "Indústria", value: lead.industry },
                { icon: Globe, label: "País", value: lead.country },
                { icon: Users, label: "Porte", value: lead.company_size },
                { icon: Clock, label: "Criado", value: timeAgo(lead.created_at) },
              ].filter(i => i.value).map(({ icon: Icon, label, value }) => (
                <div key={label} style={{ background: "hsl(var(--card))", borderRadius: 8, padding: "10px 12px", border: "1px solid hsl(var(--border))" }}>
                  <div style={{ fontSize: "0.65rem", color: "hsl(var(--muted-foreground))", marginBottom: 4, display: "flex", alignItems: "center", gap: 4 }}>
                    <Icon style={{ width: 9, height: 9 }} /> {label}
                  </div>
                  <div style={{ fontSize: "0.82rem", fontWeight: 600 }}>{value}</div>
                </div>
              ))}
            </div>

            {/* summary */}
            {lead.summary && (
              <Section title="Resumo">
                <p style={{ fontSize: "0.82rem", lineHeight: 1.6, color: "hsl(var(--foreground))", margin: 0 }}>{lead.summary}</p>
              </Section>
            )}

            {/* pain points */}
            {lead.pain_points && lead.pain_points.length > 0 && (
              <Section title="Dores identificadas">
                <ul style={{ margin: 0, paddingLeft: 0, display: "flex", flexDirection: "column", gap: 6 }}>
                  {lead.pain_points.map((p, i) => (
                    <li key={i} style={{ display: "flex", gap: 8, fontSize: "0.8rem", lineHeight: 1.5, color: "hsl(var(--foreground))", listStyle: "none" }}>
                      <span style={{ color: "#f87171", flexShrink: 0, marginTop: 3 }}>•</span>
                      {p}
                    </li>
                  ))}
                </ul>
              </Section>
            )}

            {/* opportunities */}
            {lead.opportunities && lead.opportunities.length > 0 && (
              <Section title="Oportunidades">
                <ul style={{ margin: 0, paddingLeft: 0, display: "flex", flexDirection: "column", gap: 6 }}>
                  {lead.opportunities.map((o, i) => (
                    <li key={i} style={{ display: "flex", gap: 8, fontSize: "0.8rem", lineHeight: 1.5, color: "hsl(var(--foreground))", listStyle: "none" }}>
                      <span style={{ color: "#4ade80", flexShrink: 0, marginTop: 3 }}>•</span>
                      {o}
                    </li>
                  ))}
                </ul>
              </Section>
            )}

            {/* technologies */}
            {lead.technologies && lead.technologies.length > 0 && (
              <Section title="Stack tecnológico">
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {lead.technologies.map((t, i) => (
                    <span key={i} style={{ padding: "3px 10px", borderRadius: 20, background: "hsl(var(--accent))", border: "1px solid hsl(var(--border))", fontSize: "0.72rem", fontWeight: 600 }}>{t}</span>
                  ))}
                </div>
              </Section>
            )}

            {/* contacts */}
            {lead.contacts && lead.contacts.length > 0 && (
              <Section title="Contatos">
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {lead.contacts.map((c, i) => (
                    <div key={i} style={{ background: "hsl(var(--card))", borderRadius: 8, padding: "10px 12px", border: "1px solid hsl(var(--border))", fontSize: "0.78rem" }}>
                      {c.name && <div style={{ fontWeight: 700 }}>{c.name}</div>}
                      {c.title && <div style={{ color: "hsl(var(--muted-foreground))" }}>{c.title}</div>}
                      {c.email && <div style={{ color: "hsl(var(--foreground))" }}>{c.email}</div>}
                    </div>
                  ))}
                </div>
              </Section>
            )}

            {/* analyses */}
            {lead.analyses_history && lead.analyses_history.length > 0 && (
              <Section title={`Análises (${lead.analyses_history.length})`}>
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {lead.analyses_history.map((a) => (
                    <div key={a.id} style={{ background: "hsl(var(--card))", borderRadius: 8, padding: "10px 12px", border: "1px solid hsl(var(--border))" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: "0.75rem" }}>
                        <span style={{ fontWeight: 600, textTransform: "capitalize" }}>{a.analysis_type.replace(/_/g, " ")}</span>
                        <span style={{ color: "hsl(var(--muted-foreground))" }}>{timeAgo(a.created_at)}</span>
                      </div>
                      {a.key_insights && a.key_insights.length > 0 && (
                        <ul style={{ margin: "6px 0 0", paddingLeft: 0, display: "flex", flexDirection: "column", gap: 3 }}>
                          {a.key_insights.slice(0, 3).map((ins, j) => (
                            <li key={j} style={{ fontSize: "0.72rem", color: "hsl(var(--muted-foreground))", listStyle: "none", display: "flex", gap: 5 }}>
                              <Star style={{ width: 9, height: 9, flexShrink: 0, marginTop: 2 }} />
                              {ins}
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}
                </div>
              </Section>
            )}

            {/* analyze action */}
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <select
                value={analysisType}
                onChange={e => setAnalysisType(e.target.value)}
                style={{
                  flex: 1,
                  padding: "9px 10px",
                  borderRadius: 8,
                  border: "1px solid hsl(var(--border))",
                  background: "hsl(var(--input))",
                  color: "hsl(var(--foreground))",
                  fontSize: "0.78rem",
                  cursor: "pointer",
                  outline: "none",
                }}
              >
                <option value="deep_analysis">Análise Profunda (15cr)</option>
                <option value="scoring">Scoring BANT/ICP (10cr)</option>
                <option value="competitive">Análise Competitiva (15cr)</option>
                <option value="intent">Intenção de Compra (15cr)</option>
                <option value="icp_fit">Fit com ICP (15cr)</option>
              </select>

              <button
                onClick={handleAnalyze}
                disabled={analyzing}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "9px 16px", borderRadius: 8,
                  border: "none",
                  background: analyzing ? "hsl(var(--muted))" : "hsl(var(--primary))",
                  color: analyzing ? "hsl(var(--muted-foreground))" : "hsl(var(--primary-foreground))",
                  fontWeight: 700, fontSize: "0.78rem", cursor: analyzing ? "not-allowed" : "pointer",
                  transition: "all 0.2s",
                  whiteSpace: "nowrap",
                }}
              >
                {analyzing ? <RefreshCw style={{ width: 12, height: 12, animation: "spin 1s linear infinite" }} /> : <Sparkles style={{ width: 12, height: 12 }} />}
                {analyzing ? "…" : "Analisar"}
              </button>
            </div>
          </div>
        ) : (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: "hsl(var(--muted-foreground))", fontSize: "0.82rem" }}>
            Lead não encontrado
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <div style={{ fontSize: "0.68rem", fontWeight: 700, color: "hsl(var(--muted-foreground))", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: 10 }}>{title}</div>
      {children}
    </div>
  );
}

// ── Main Leads Page ───────────────────────────────────────────────────────────

const STATUS_OPTIONS = ["", "new", "qualified", "contacted", "proposal", "won", "lost"];

export default function Leads() {
  const navigate = useNavigate();
  const token = getToken();

  const [leads, setLeads] = useState<Lead[]>([]);
  const [stats, setStats] = useState<LeadStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [statsLoading, setStatsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalLeads, setTotalLeads] = useState(0);

  // filters
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [minScore, setMinScore] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  // modals
  const [showDiscover, setShowDiscover] = useState(false);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);

  // per-card actions
  const [analyzingIds, setAnalyzingIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!token) { navigate("/login", { replace: true }); }
  }, [token, navigate]);

  const loadLeads = useCallback(async (p = 1) => {
    if (!token) return;
    setLoading(true);
    try {
      const params: Record<string, string | number> = { page: p, per_page: 15 };
      if (search) params.search = search;
      if (statusFilter) params.status = statusFilter;
      if (minScore) params.min_score = Number(minScore);
      const data = await fetchLeads(token, params);
      setLeads(data.leads);
      setTotalPages(data.total_pages || 1);
      setTotalLeads(data.total || 0);
      setPage(p);
    } catch { /* silently */ }
    finally { setLoading(false); }
  }, [token, search, statusFilter, minScore]);

  const loadStats = useCallback(async () => {
    if (!token) return;
    setStatsLoading(true);
    try {
      const s = await fetchLeadStats(token);
      setStats(s);
    } catch { /* silently */ }
    finally { setStatsLoading(false); }
  }, [token]);

  useEffect(() => { loadLeads(1); }, [loadLeads]);
  useEffect(() => { loadStats(); }, [loadStats]);

  const handleArchive = async (e: React.MouseEvent, leadId: string) => {
    e.stopPropagation();
    if (!token) return;
    try {
      await archiveLead(token, leadId);
      loadLeads(page);
      loadStats();
    } catch { /* silently */ }
  };

  const handleAnalyzeCard = async (e: React.MouseEvent, leadId: string) => {
    e.stopPropagation();
    if (!token) return;
    setAnalyzingIds(s => new Set(s).add(leadId));
    try {
      await analyzeLead(token, leadId);
      loadLeads(page);
    } catch { /* silently */ }
    finally {
      setAnalyzingIds(s => { const n = new Set(s); n.delete(leadId); return n; });
    }
  };

  // search debounce
  useEffect(() => {
    const t = setTimeout(() => loadLeads(1), 400);
    return () => clearTimeout(t);
  }, [search, statusFilter, minScore]); // eslint-disable-line

  return (
    <div style={{ minHeight: "100vh", background: "hsl(var(--background))", color: "hsl(var(--foreground))", display: "flex", flexDirection: "column" }}>
      {/* keyframes */}
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(16px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes slideRight { from { opacity: 0; transform: translateX(24px); } to { opacity: 1; transform: translateX(0); } }
      `}</style>

      {/* header */}
      <header style={{ borderBottom: "1px solid hsl(var(--border))", padding: "14px 24px", display: "flex", alignItems: "center", gap: 14, position: "sticky", top: 0, background: "hsl(var(--background))", zIndex: 100 }}>
        <button
          onClick={() => navigate("/chats")}
          style={{ display: "flex", alignItems: "center", gap: 6, background: "none", border: "none", cursor: "pointer", color: "hsl(var(--muted-foreground))", padding: 4, fontSize: "0.8rem", transition: "color 0.15s" }}
          onMouseEnter={e => (e.currentTarget.style.color = "hsl(var(--foreground))")}
          onMouseLeave={e => (e.currentTarget.style.color = "hsl(var(--muted-foreground))")}
        >
          <ArrowLeft style={{ width: 14, height: 14 }} />
        </button>

        <div style={{ width: 1, height: 18, background: "hsl(var(--border))" }} />

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Target style={{ width: 15, height: 15, color: "hsl(var(--muted-foreground))" }} />
          <span style={{ fontWeight: 700, fontSize: "0.92rem", letterSpacing: "-0.02em" }}>Leads</span>
          {totalLeads > 0 && (
            <span style={{ fontSize: "0.68rem", padding: "1px 7px", borderRadius: 20, background: "hsl(var(--accent))", color: "hsl(var(--muted-foreground))", fontWeight: 600 }}>
              {totalLeads}
            </span>
          )}
        </div>

        <div style={{ flex: 1 }} />

        <button
          onClick={() => loadLeads(page)}
          style={{ background: "none", border: "none", cursor: "pointer", color: "hsl(var(--muted-foreground))", padding: 6, borderRadius: 6, transition: "color 0.15s" }}
          title="Atualizar"
        >
          <RefreshCw style={{ width: 13, height: 13 }} />
        </button>

        <button
          onClick={() => setShowDiscover(true)}
          style={{
            display: "flex", alignItems: "center", gap: 6,
            padding: "7px 14px", borderRadius: 8,
            border: "none",
            background: "hsl(var(--primary))",
            color: "hsl(var(--primary-foreground))",
            fontWeight: 700, fontSize: "0.78rem", cursor: "pointer",
            transition: "opacity 0.15s",
          }}
          onMouseEnter={e => (e.currentTarget.style.opacity = "0.85")}
          onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
        >
          <Plus style={{ width: 12, height: 12 }} />
          Descobrir
        </button>
      </header>

      {/* content */}
      <main style={{ flex: 1, padding: "24px", maxWidth: 900, margin: "0 auto", width: "100%", boxSizing: "border-box" }}>

        {/* stats row */}
        {!statsLoading && stats && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12, marginBottom: 28 }}>
            <StatCard label="Total Leads" value={stats.total_leads} icon={Layers} />
            <StatCard label="Score médio" value={stats.score_stats.average > 0 ? `${stats.score_stats.average}` : "—"} icon={TrendingUp} sub={stats.score_stats.max > 0 ? `máx ${stats.score_stats.max}` : undefined} />
            <StatCard label="Buscas" value={stats.total_searches} icon={Search} />
            <StatCard label="Análises" value={stats.total_analyses} icon={BarChart2} />
          </div>
        )}

        {/* search + filters */}
        <div style={{ display: "flex", gap: 10, marginBottom: 16, alignItems: "center" }}>
          <div style={{ flex: 1, position: "relative" }}>
            <Search style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", width: 13, height: 13, color: "hsl(var(--muted-foreground))", pointerEvents: "none" }} />
            <input
              style={{
                width: "100%",
                padding: "9px 12px 9px 32px",
                borderRadius: 8,
                border: "1px solid hsl(var(--border))",
                background: "hsl(var(--input))",
                color: "hsl(var(--foreground))",
                fontSize: "0.82rem",
                outline: "none",
                boxSizing: "border-box",
                transition: "border-color 0.15s",
              }}
              placeholder="Buscar empresa…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onFocus={e => (e.target.style.borderColor = "rgba(255,255,255,0.3)")}
              onBlur={e => (e.target.style.borderColor = "hsl(var(--border))")}
            />
          </div>

          <button
            onClick={() => setShowFilters(f => !f)}
            style={{
              display: "flex", alignItems: "center", gap: 5,
              padding: "9px 12px", borderRadius: 8,
              border: "1px solid hsl(var(--border))",
              background: showFilters ? "hsl(var(--accent))" : "transparent",
              color: "hsl(var(--foreground))",
              fontSize: "0.78rem", fontWeight: 600, cursor: "pointer",
              whiteSpace: "nowrap",
            }}
          >
            <Filter style={{ width: 11, height: 11 }} />
            Filtros
            <ChevronDown style={{ width: 11, height: 11, transition: "transform 0.2s", transform: showFilters ? "rotate(180deg)" : "none" }} />
          </button>
        </div>

        {showFilters && (
          <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              style={{
                padding: "8px 12px", borderRadius: 8,
                border: "1px solid hsl(var(--border))",
                background: "hsl(var(--input))",
                color: "hsl(var(--foreground))",
                fontSize: "0.78rem", cursor: "pointer", outline: "none",
              }}
            >
              <option value="">Todos os status</option>
              {STATUS_OPTIONS.filter(Boolean).map(s => (
                <option key={s} value={s}>{statusLabel(s)}</option>
              ))}
            </select>

            <input
              type="number"
              min={0} max={100}
              placeholder="Score mínimo"
              value={minScore}
              onChange={e => setMinScore(e.target.value)}
              style={{
                padding: "8px 12px", borderRadius: 8, width: 140,
                border: "1px solid hsl(var(--border))",
                background: "hsl(var(--input))",
                color: "hsl(var(--foreground))",
                fontSize: "0.78rem", outline: "none",
              }}
            />

            {(statusFilter || minScore || search) && (
              <button
                onClick={() => { setStatusFilter(""); setMinScore(""); setSearch(""); }}
                style={{
                  display: "flex", alignItems: "center", gap: 4,
                  padding: "8px 12px", borderRadius: 8,
                  border: "1px solid hsl(var(--border))",
                  background: "transparent",
                  color: "hsl(var(--muted-foreground))",
                  fontSize: "0.78rem", cursor: "pointer",
                }}
              >
                <X style={{ width: 10, height: 10 }} /> Limpar
              </button>
            )}
          </div>
        )}

        {/* leads list */}
        {loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[...Array(4)].map((_, i) => (
              <div key={i} style={{ height: 120, borderRadius: 12, background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", opacity: 0.5 + i * 0.1 }} />
            ))}
          </div>
        ) : leads.length === 0 ? (
          <div style={{
            textAlign: "center", padding: "60px 24px",
            border: "1px dashed hsl(var(--border))",
            borderRadius: 12,
            display: "flex", flexDirection: "column", alignItems: "center", gap: 12,
          }}>
            <Target style={{ width: 32, height: 32, color: "hsl(var(--muted-foreground))", opacity: 0.5 }} />
            <div style={{ fontWeight: 700, fontSize: "0.92rem" }}>Nenhum lead encontrado</div>
            <div style={{ fontSize: "0.78rem", color: "hsl(var(--muted-foreground))" }}>
              {search || statusFilter || minScore
                ? "Tente mudar os filtros"
                : 'Clique em "Descobrir" para buscar empresas com IA'}
            </div>
            {!search && !statusFilter && !minScore && (
              <button
                onClick={() => setShowDiscover(true)}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "9px 18px", borderRadius: 8,
                  border: "1px solid hsl(var(--border))",
                  background: "transparent",
                  color: "hsl(var(--foreground))",
                  fontWeight: 700, fontSize: "0.8rem", cursor: "pointer",
                  marginTop: 8,
                }}
              >
                <Zap style={{ width: 12, height: 12 }} />
                Descobrir Leads
              </button>
            )}
          </div>
        ) : (
          <>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {leads.map(lead => (
                <LeadCard
                  key={lead.id}
                  lead={lead}
                  onClick={() => setSelectedLeadId(lead.id)}
                  onAnalyze={e => handleAnalyzeCard(e, lead.id)}
                  onArchive={e => handleArchive(e, lead.id)}
                  analyzing={analyzingIds.has(lead.id)}
                />
              ))}
            </div>

            {/* pagination */}
            {totalPages > 1 && (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 24 }}>
                <button
                  disabled={page === 1}
                  onClick={() => loadLeads(page - 1)}
                  style={{
                    padding: "6px 14px", borderRadius: 6,
                    border: "1px solid hsl(var(--border))",
                    background: "transparent",
                    color: page === 1 ? "hsl(var(--muted-foreground))" : "hsl(var(--foreground))",
                    fontSize: "0.78rem", cursor: page === 1 ? "not-allowed" : "pointer",
                  }}
                >
                  Anterior
                </button>
                <span style={{ fontSize: "0.78rem", color: "hsl(var(--muted-foreground))" }}>
                  {page} / {totalPages}
                </span>
                <button
                  disabled={page === totalPages}
                  onClick={() => loadLeads(page + 1)}
                  style={{
                    padding: "6px 14px", borderRadius: 6,
                    border: "1px solid hsl(var(--border))",
                    background: "transparent",
                    color: page === totalPages ? "hsl(var(--muted-foreground))" : "hsl(var(--foreground))",
                    fontSize: "0.78rem", cursor: page === totalPages ? "not-allowed" : "pointer",
                  }}
                >
                  Próxima
                </button>
              </div>
            )}
          </>
        )}
      </main>

      {/* modals */}
      {showDiscover && (
        <DiscoverModal
          onClose={() => setShowDiscover(false)}
          onSuccess={() => { loadLeads(1); loadStats(); }}
        />
      )}

      {selectedLeadId && (
        <LeadDetailPanel
          leadId={selectedLeadId}
          onClose={() => setSelectedLeadId(null)}
          onRefresh={() => { loadLeads(page); loadStats(); }}
        />
      )}
    </div>
  );
}
