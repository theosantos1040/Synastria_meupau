import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Menu,
  Plus,
  ChevronDown,
  ExternalLink,
  X,
  CheckCircle2,
  Loader2,
  AlertCircle,
  ArrowUp,
  Globe,
  Clock,
} from "lucide-react";
import {
  getToken,
  fetchMySites,
  createSiteViaSandbox,
  type PublishedSite,
} from "@/lib/api";
import StarLogo from "@/components/StarLogo";

// ── helpers ───────────────────────────────────────────────────────────────────

function timeAgo(dateStr: string) {
  const d = new Date(dateStr);
  const diff = Date.now() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "agora";
  if (mins < 60) return `${mins}m atrás`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h atrás`;
  return `${Math.floor(hrs / 24)}d atrás`;
}

// ── Build step types ──────────────────────────────────────────────────────────

type BuildStep = {
  id: string;
  label: string;
  status: "pending" | "running" | "done" | "error";
};

const INITIAL_STEPS: BuildStep[] = [
  { id: "classifying", label: "Analisando prompt", status: "pending" },
  { id: "generating",  label: "Gerando HTML/CSS/JS", status: "pending" },
  { id: "executing",   label: "Processando no sandbox", status: "pending" },
  { id: "uploading",   label: "Publicando site", status: "pending" },
];

type Tab = "chat" | "preview";

// ── Step icon ─────────────────────────────────────────────────────────────────

function StepIcon({ status }: { status: BuildStep["status"] }) {
  if (status === "done")    return <CheckCircle2 style={{ width: 13, height: 13, color: "#4ade80" }} />;
  if (status === "running") return <Loader2 style={{ width: 13, height: 13, color: "hsl(0 0% 70%)", animation: "spin 1s linear infinite" }} />;
  if (status === "error")   return <AlertCircle style={{ width: 13, height: 13, color: "#f87171" }} />;
  return <div style={{ width: 11, height: 11, borderRadius: "50%", border: "1.5px solid rgba(255,255,255,0.2)", flexShrink: 0 }} />;
}

// ── Main Code Page ────────────────────────────────────────────────────────────

export default function Code() {
  const navigate = useNavigate();
  const token = getToken();

  const [sites, setSites] = useState<PublishedSite[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSite, setSelectedSite] = useState<PublishedSite | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("chat");

  const [prompt, setPrompt] = useState("");
  const [building, setBuilding] = useState(false);
  const [steps, setSteps] = useState<BuildStep[]>(INITIAL_STEPS.map(s => ({ ...s })));
  const [buildError, setBuildError] = useState("");
  const [buildDone, setBuildDone] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const pickerRef = useRef<HTMLDivElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!token) { navigate("/login", { replace: true }); }
  }, [token, navigate]);

  const loadSites = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const data = await fetchMySites(token);
      setSites(data);
      if (data.length > 0 && !selectedSite) setSelectedSite(data[0]);
    } catch { /* silently */ }
    finally { setLoading(false); }
  }, [token, selectedSite]);

  useEffect(() => { loadSites(); }, [loadSites]);

  // Auto-resize textarea
  useEffect(() => {
    const el = textareaRef.current;
    if (el) {
      el.style.height = "auto";
      el.style.height = Math.min(el.scrollHeight, 120) + "px";
    }
  }, [prompt]);

  // Scroll to bottom when building
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [steps, buildDone, buildError]);

  // Close picker on outside click
  useEffect(() => {
    const handle = (e: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target as Node)) {
        setPickerOpen(false);
      }
    };
    document.addEventListener("mousedown", handle);
    return () => document.removeEventListener("mousedown", handle);
  }, []);

  const updateStep = (id: string, status: BuildStep["status"]) =>
    setSteps(prev => prev.map(s => s.id === id ? { ...s, status } : s));

  const handleSend = async () => {
    const trimmed = prompt.trim();
    if (!trimmed || building) return;
    if (!token) return;

    setBuilding(true);
    setBuildError("");
    setBuildDone(false);
    setSteps(INITIAL_STEPS.map(s => ({ ...s })));
    setActiveTab("chat");
    setPrompt("");

    try {
      const res = await createSiteViaSandbox(token, trimmed, (type, data) => {
        if (type === "classifying") updateStep("classifying", "running");
        if (type === "planned")     { updateStep("classifying", "done"); updateStep("generating", "running"); }
        if (type === "generating")  updateStep("generating", "running");
        if (type === "code_generated") { updateStep("generating", "done"); updateStep("executing", "running"); }
        if (type === "executing")   updateStep("executing", "running");
        if (type === "uploading")   { updateStep("executing", "done"); updateStep("uploading", "running"); }
        if (type === "done") {
          setSteps(prev => prev.map(s => ({ ...s, status: "done" })));
          if (data.public_url) {
            const newSite: PublishedSite = {
              slug: (data.public_url as string).split("/s/")[1] || "",
              title: (data.title as string) || "Meu Site",
              public_url: data.public_url as string,
              created_at: new Date().toISOString(),
            };
            setSites(prev => [newSite, ...prev]);
            setSelectedSite(newSite);
            setBuildDone(true);
          }
        }
        if (type === "error") {
          setSteps(prev => prev.map(s => s.status === "running" ? { ...s, status: "error" } : s));
        }
      });

      if (res.public_url && !buildDone) {
        const newSite: PublishedSite = {
          slug: res.public_url.split("/s/")[1] || "",
          title: res.title || "Meu Site",
          public_url: res.public_url,
          created_at: new Date().toISOString(),
        };
        setSites(prev => [newSite, ...prev]);
        setSelectedSite(newSite);
        setBuildDone(true);
      }
    } catch (e) {
      setBuildError(e instanceof Error ? e.message : "Erro ao criar site");
      setSteps(prev => prev.map(s => s.status === "running" ? { ...s, status: "error" } : s));
    } finally {
      setBuilding(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const isEmpty = !building && !buildDone && !buildError;
  const projectTitle = selectedSite?.title ?? "New project";
  const canSend = prompt.trim().length > 0 && !building;

  return (
    <div
      style={{
        minHeight: "100dvh",
        height: "100dvh",
        background: "radial-gradient(ellipse at 50% 72%, #2c2c2c 0%, #111 42%, #000 100%)",
        color: "white",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(10px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        @keyframes codePulse {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.04); }
        }
        .code-step-row { animation: fadeUp 0.3s ease forwards; }
        .code-step-row:nth-child(1) { animation-delay: 0ms; }
        .code-step-row:nth-child(2) { animation-delay: 60ms; }
        .code-step-row:nth-child(3) { animation-delay: 120ms; }
        .code-step-row:nth-child(4) { animation-delay: 180ms; }
        .code-tab-btn {
          padding: 7px 22px;
          border-radius: 9999px;
          border: none;
          cursor: pointer;
          font-size: 0.88rem;
          font-weight: 600;
          letter-spacing: -0.01em;
          transition: all 180ms cubic-bezier(0.23, 1, 0.32, 1);
          font-family: inherit;
        }
        .code-tab-btn--active {
          background: #252525;
          color: white;
        }
        .code-tab-btn--inactive {
          background: transparent;
          color: rgba(255,255,255,0.4);
        }
        .code-tab-btn--inactive:hover {
          color: rgba(255,255,255,0.65);
        }
        .code-picker-item {
          display: flex; align-items: center; gap: 10px;
          padding: 10px 14px;
          border: none; background: none;
          width: 100%; text-align: left;
          cursor: pointer;
          color: rgba(255,255,255,0.75);
          font-size: 0.82rem; font-weight: 500;
          border-radius: 8px;
          transition: background 150ms ease, color 150ms ease;
          font-family: inherit;
        }
        .code-picker-item:hover {
          background: rgba(255,255,255,0.07);
          color: white;
        }
        .code-picker-item--active {
          color: white;
          background: rgba(255,255,255,0.06);
        }
      `}</style>

      {/* ── Header ── */}
      <header style={{
        position: "relative",
        display: "flex",
        alignItems: "center",
        padding: "14px 18px",
        flexShrink: 0,
        zIndex: 20,
      }}>
        {/* Left: hamburger */}
        <button
          onClick={() => navigate("/chats")}
          style={{
            width: 36, height: 36,
            display: "flex", alignItems: "center", justifyContent: "center",
            background: "none", border: "none", cursor: "pointer",
            color: "rgba(255,255,255,0.55)",
            borderRadius: 8,
            transition: "color 150ms ease",
            flexShrink: 0,
          }}
          onMouseEnter={e => (e.currentTarget.style.color = "rgba(255,255,255,0.85)")}
          onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.55)")}
          aria-label="Menu"
        >
          <Menu style={{ width: 18, height: 18 }} />
        </button>

        {/* Center: project picker */}
        <div
          ref={pickerRef}
          style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", zIndex: 10 }}
        >
          <button
            onClick={() => setPickerOpen(o => !o)}
            style={{
              display: "flex", alignItems: "center", gap: 5,
              background: "none", border: "none", cursor: "pointer",
              color: "rgba(255,255,255,0.6)",
              fontFamily: "'ClashDisplay-Variable', 'Clash Display', 'SF Pro Display', sans-serif",
              fontWeight: 500,
              fontSize: "0.88rem",
              letterSpacing: "-0.015em",
              padding: "6px 10px",
              borderRadius: 8,
              transition: "color 150ms ease",
              whiteSpace: "nowrap",
            }}
            onMouseEnter={e => (e.currentTarget.style.color = "rgba(255,255,255,0.85)")}
            onMouseLeave={e => (e.currentTarget.style.color = "rgba(255,255,255,0.6)")}
          >
            <span style={{ maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis" }}>
              {projectTitle}
            </span>
            <ChevronDown
              style={{
                width: 13, height: 13,
                opacity: 0.5,
                transition: "transform 180ms ease",
                transform: pickerOpen ? "rotate(180deg)" : "rotate(0deg)",
                flexShrink: 0,
              }}
            />
          </button>

          {/* Picker dropdown */}
          {pickerOpen && (
            <div style={{
              position: "absolute",
              top: "calc(100% + 6px)",
              left: "50%",
              transform: "translateX(-50%)",
              minWidth: 220,
              background: "hsl(0 0% 8%)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 12,
              padding: 6,
              boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
              animation: "fadeUp 0.18s ease",
            }}>
              {/* New project */}
              <button
                className="code-picker-item"
                onClick={() => {
                  setSelectedSite(null);
                  setBuildDone(false);
                  setBuildError("");
                  setSteps(INITIAL_STEPS.map(s => ({ ...s })));
                  setPickerOpen(false);
                  setActiveTab("chat");
                }}
              >
                <div style={{
                  width: 26, height: 26, borderRadius: 6,
                  background: "rgba(255,255,255,0.07)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0,
                }}>
                  <Plus style={{ width: 12, height: 12 }} />
                </div>
                <span>New project</span>
              </button>

              {/* Separator */}
              {sites.length > 0 && (
                <div style={{
                  height: 1,
                  background: "rgba(255,255,255,0.07)",
                  margin: "4px 0",
                }} />
              )}

              {/* Existing sites */}
              {loading ? (
                <div style={{ padding: "10px 14px", color: "rgba(255,255,255,0.3)", fontSize: "0.78rem" }}>
                  <Loader2 style={{ width: 12, height: 12, animation: "spin 1s linear infinite", display: "inline" }} /> Carregando...
                </div>
              ) : (
                sites.slice(0, 8).map(site => (
                  <button
                    key={site.slug}
                    className={`code-picker-item${selectedSite?.slug === site.slug ? " code-picker-item--active" : ""}`}
                    onClick={() => {
                      setSelectedSite(site);
                      setBuildDone(true);
                      setPickerOpen(false);
                      setActiveTab("preview");
                    }}
                  >
                    <div style={{
                      width: 26, height: 26, borderRadius: 6,
                      background: "rgba(255,255,255,0.05)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      flexShrink: 0,
                    }}>
                      <Globe style={{ width: 11, height: 11, color: "rgba(255,255,255,0.4)" }} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{
                        fontWeight: 600,
                        whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                        fontSize: "0.82rem",
                      }}>
                        {site.title}
                      </div>
                      <div style={{ fontSize: "0.68rem", color: "rgba(255,255,255,0.3)", display: "flex", alignItems: "center", gap: 3, marginTop: 1 }}>
                        <Clock style={{ width: 9, height: 9 }} />
                        {timeAgo(site.created_at)}
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
          )}
        </div>

        {/* Right: spacer (matches left button width) */}
        <div style={{ width: 36, flexShrink: 0, marginLeft: "auto" }} />
      </header>

      {/* ── Main content ── */}
      <main style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        position: "relative",
      }}>

        {/* Preview tab */}
        {activeTab === "preview" && selectedSite ? (
          <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
            {/* Preview toolbar */}
            <div style={{
              display: "flex", alignItems: "center", gap: 8,
              padding: "8px 18px",
              borderBottom: "1px solid rgba(255,255,255,0.06)",
              flexShrink: 0,
            }}>
              <div style={{
                flex: 1, height: 32, borderRadius: 8,
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                display: "flex", alignItems: "center",
                padding: "0 12px",
                fontSize: "0.75rem",
                color: "rgba(255,255,255,0.35)",
                overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
              }}>
                {selectedSite.public_url}
              </div>
              <a
                href={selectedSite.public_url}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  width: 32, height: 32, borderRadius: 8,
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "rgba(255,255,255,0.55)",
                  flexShrink: 0,
                }}
              >
                <ExternalLink style={{ width: 13, height: 13 }} />
              </a>
            </div>
            {/* iFrame preview */}
            <iframe
              src={selectedSite.public_url}
              style={{ flex: 1, border: "none", width: "100%", background: "white" }}
              title={selectedSite.title}
            />
          </div>
        ) : (
          /* Chat tab content */
          <div style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            overflowY: "auto",
            paddingBottom: 160,
          }}>
            {isEmpty ? (
              /* Empty state */
              <div style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 14,
                padding: "0 32px",
                animation: "fadeUp 0.5s ease",
              }}>
                <div style={{ position: "relative" }}>
                  <div style={{
                    position: "absolute",
                    inset: "-30px",
                    borderRadius: "50%",
                    background: "radial-gradient(circle, rgba(255,255,255,0.04), transparent 70%)",
                    pointerEvents: "none",
                  }} />
                  <StarLogo
                    style={{
                      width: 80, height: 80,
                      filter: "grayscale(100%) brightness(1.1)",
                      animation: "codePulse 3.5s ease-in-out infinite",
                      position: "relative",
                      zIndex: 1,
                    }}
                  />
                </div>
                <p style={{
                  fontFamily: "'ClashDisplay-Variable', 'Clash Display', 'SF Pro Display', sans-serif",
                  fontWeight: 500,
                  fontSize: "clamp(1.1rem, 4vw, 1.4rem)",
                  color: "rgba(255,255,255,0.82)",
                  letterSpacing: "-0.025em",
                  margin: 0,
                  textAlign: "center",
                  lineHeight: 1.25,
                }}>
                  What are we coding today?
                </p>
              </div>
            ) : (
              /* Build progress */
              <div style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                padding: "28px 20px 0",
                gap: 24,
              }}>
                {/* Build steps card */}
                <div style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.09)",
                  borderRadius: 16,
                  padding: "18px 20px",
                  display: "flex",
                  flexDirection: "column",
                  gap: 12,
                  animation: "fadeUp 0.3s ease",
                  maxWidth: 440,
                  margin: "0 auto",
                  width: "100%",
                }}>
                  <div style={{
                    fontSize: "0.72rem",
                    fontWeight: 700,
                    letterSpacing: "0.06em",
                    textTransform: "uppercase",
                    color: "rgba(255,255,255,0.3)",
                    marginBottom: 4,
                  }}>
                    Building
                  </div>

                  {steps.map((s, i) => (
                    <div
                      key={s.id}
                      className="code-step-row"
                      style={{
                        display: "flex", alignItems: "center", gap: 10,
                        opacity: s.status === "pending" ? 0.35 : 1,
                        transition: "opacity 0.25s ease",
                      }}
                    >
                      <StepIcon status={s.status} />
                      <span style={{
                        fontSize: "0.82rem",
                        color: s.status === "error"
                          ? "#f87171"
                          : s.status === "done"
                          ? "rgba(255,255,255,0.8)"
                          : "rgba(255,255,255,0.75)",
                        fontWeight: s.status === "running" ? 600 : 400,
                        transition: "color 0.2s, font-weight 0.2s",
                      }}>
                        {s.label}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Error */}
                {buildError && (
                  <div style={{
                    display: "flex", alignItems: "flex-start", gap: 8,
                    color: "#f87171", fontSize: "0.8rem",
                    background: "rgba(248,113,113,0.07)",
                    border: "1px solid rgba(248,113,113,0.2)",
                    borderRadius: 10, padding: "12px 14px",
                    animation: "fadeUp 0.25s ease",
                    maxWidth: 440, margin: "0 auto", width: "100%",
                  }}>
                    <AlertCircle style={{ width: 13, height: 13, flexShrink: 0, marginTop: 1 }} />
                    {buildError}
                  </div>
                )}

                {/* Done: show link + open preview */}
                {buildDone && selectedSite && (
                  <div style={{
                    display: "flex", flexDirection: "column", gap: 10,
                    maxWidth: 440, margin: "0 auto", width: "100%",
                    animation: "fadeUp 0.3s ease",
                  }}>
                    <div style={{
                      background: "rgba(74,222,128,0.06)",
                      border: "1px solid rgba(74,222,128,0.18)",
                      borderRadius: 12, padding: "14px 16px",
                      display: "flex", flexDirection: "column", gap: 6,
                    }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <CheckCircle2 style={{ width: 13, height: 13, color: "#4ade80" }} />
                        <span style={{ fontWeight: 700, fontSize: "0.85rem" }}>{selectedSite.title}</span>
                      </div>
                      <span style={{
                        fontSize: "0.72rem",
                        color: "rgba(255,255,255,0.35)",
                        wordBreak: "break-all",
                      }}>
                        {selectedSite.public_url}
                      </span>
                    </div>

                    <div style={{ display: "flex", gap: 8 }}>
                      <button
                        onClick={() => setActiveTab("preview")}
                        style={{
                          flex: 1, padding: "10px 0", borderRadius: 9999,
                          background: "white", color: "black",
                          border: "none", fontWeight: 700, fontSize: "0.82rem",
                          cursor: "pointer", fontFamily: "inherit",
                          transition: "opacity 0.15s",
                        }}
                        onMouseEnter={e => (e.currentTarget.style.opacity = "0.85")}
                        onMouseLeave={e => (e.currentTarget.style.opacity = "1")}
                      >
                        Ver Preview
                      </button>
                      <a
                        href={selectedSite.public_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{
                          padding: "10px 14px", borderRadius: 9999,
                          border: "1px solid rgba(255,255,255,0.12)",
                          background: "transparent", color: "rgba(255,255,255,0.7)",
                          display: "flex", alignItems: "center", gap: 5,
                          fontSize: "0.82rem", textDecoration: "none",
                          transition: "border-color 0.15s",
                        }}
                      >
                        <ExternalLink style={{ width: 12, height: 12 }} />
                        Abrir
                      </a>
                    </div>
                  </div>
                )}

                <div ref={chatBottomRef} />
              </div>
            )}
          </div>
        )}
      </main>

      {/* ── Bottom controls ── */}
      <div style={{
        position: "fixed",
        bottom: 0, left: 0, right: 0,
        display: "flex", flexDirection: "column",
        alignItems: "center",
        padding: "12px 16px",
        paddingBottom: "max(env(safe-area-inset-bottom, 0px), 18px)",
        gap: 10,
        zIndex: 50,
        background: "linear-gradient(to top, rgba(0,0,0,0.92) 0%, transparent 100%)",
      }}>
        {/* Chat / Preview tab toggle */}
        <div style={{
          display: "flex",
          background: "rgba(0,0,0,0.6)",
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 9999,
          padding: 3,
          backdropFilter: "blur(20px)",
          gap: 1,
        }}>
          <button
            className={`code-tab-btn code-tab-btn--${activeTab === "chat" ? "active" : "inactive"}`}
            onClick={() => setActiveTab("chat")}
          >
            Chat
          </button>
          <button
            className={`code-tab-btn code-tab-btn--${activeTab === "preview" ? "active" : "inactive"}`}
            onClick={() => {
              if (selectedSite) setActiveTab("preview");
            }}
            style={{ opacity: selectedSite ? 1 : 0.4, cursor: selectedSite ? "pointer" : "not-allowed" }}
          >
            Preview
          </button>
        </div>

        {/* Input pill */}
        <div style={{ width: "100%", maxWidth: 640 }}>
          <div
            className={`inputbar-pill${prompt.includes("\n") ? " inputbar-pill--expanded" : ""}`}
          >
            <div className="inputbar-pill-row">
              <button
                className="inputbar-plus-btn"
                disabled={building}
                onClick={() => {
                  // Reset to new project
                  setSelectedSite(null);
                  setBuildDone(false);
                  setBuildError("");
                  setSteps(INITIAL_STEPS.map(s => ({ ...s })));
                  setActiveTab("chat");
                }}
                title="New project"
              >
                <Plus style={{ width: 18, height: 18 }} />
              </button>

              <textarea
                ref={textareaRef}
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={building}
                placeholder="Lucianize it..."
                rows={1}
                className="inputbar-pill-textarea"
                style={{ flex: 1 }}
              />

              <button
                onClick={handleSend}
                disabled={!canSend}
                className="inputbar-circle-btn"
                style={{ opacity: canSend ? 1 : 0.3 }}
              >
                {building
                  ? <Loader2 style={{ width: 16, height: 16, animation: "spin 1s linear infinite" }} />
                  : <ArrowUp style={{ width: 16, height: 16 }} />
                }
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
