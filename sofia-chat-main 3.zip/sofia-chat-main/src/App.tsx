import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";
import Products from "./pages/Products";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Chats from "./pages/Chats";
import SharedChat from "./pages/SharedChat";
import Settings from "./pages/Settings";
import Customization from "./pages/Customization";
import NotFound from "./pages/NotFound";
import Leads from "./pages/Leads";
import Code from "./pages/Code";
import Blog from "./pages/Blog";
import PageTransition from "./components/PageTransition";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route element={<PageTransition />}>
            <Route path="/" element={<Landing />} />
            <Route path="/products" element={<Products />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            {/* Chat routes — with and without conversation ID */}
            <Route path="/chats" element={<Chats />} />
            <Route path="/chats/:conversationId" element={<Chats />} />

            {/* Settings routes */}
            <Route path="/settings" element={<Settings />} />
            <Route path="/settings/customization" element={<Customization />} />

            {/* Leads */}
            <Route path="/leads" element={<Leads />} />

            {/* Code / Web Developer */}
            <Route path="/code" element={<Code />} />

            {/* Blog */}
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<Blog />} />

            {/* Public shared conversation view */}
            <Route path="/share/:shareId" element={<SharedChat />} />

            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
