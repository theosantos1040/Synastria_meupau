import StarLogo from "./StarLogo";
import { motion } from "framer-motion";

const ROLES = ["Lead-Agent", "Web Developer", "Analyst"];

interface HeroViewProps {
  visible: boolean;
  onRoleSelect?: (role: string) => void;
}

const HeroView = ({ visible, onRoleSelect }: HeroViewProps) => {
  return (
    <div
      className="hero-container"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(-40px)",
        pointerEvents: visible ? "auto" : "none",
      }}
    >
      <motion.div
        className="hero-inner"
        initial={{ opacity: 0, scale: 0.92, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.55, ease: [0.23, 1, 0.32, 1] }}
        style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}
      >
        <div className="hero-glow" />
        <StarLogo
          className="w-[88px] h-[88px] animate-star-pulse relative z-10"
          style={{ filter: "grayscale(100%) brightness(1.2)" }}
        />

        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2, ease: [0.23, 1, 0.32, 1] }}
          style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}
        >
          <p
            style={{
              fontFamily: "'ClashDisplay-Variable', 'Clash Display', sans-serif",
              fontWeight: 600,
              fontSize: "clamp(1.15rem, 3.8vw, 1.55rem)",
              color: "hsl(0 0% 88%)",
              letterSpacing: "-0.025em",
              margin: 0,
              textAlign: "center",
              lineHeight: 1.2,
            }}
          >
            How can I help you today?
          </p>
          <p
            style={{
              fontFamily: "'ClashDisplay-Variable', 'Clash Display', sans-serif",
              fontWeight: 400,
              fontSize: "clamp(0.85rem, 2.2vw, 1rem)",
              color: "hsl(0 0% 50%)",
              letterSpacing: "-0.01em",
              margin: 0,
              textAlign: "center",
            }}
          >
            I can be your:
          </p>
        </motion.div>

        <motion.div
          className="hero-chips"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.35, ease: [0.23, 1, 0.32, 1] }}
        >
          {ROLES.map((role) => (
            <button
              key={role}
              className="hero-role-chip"
              onClick={() => onRoleSelect?.(role)}
            >
              {role}
            </button>
          ))}
        </motion.div>
      </motion.div>
    </div>
  );
};

export default HeroView;
