import { useState, useRef, useCallback } from "react";
import { Volume2, Pause, Loader2, Brain, ChevronDown, ChevronUp, Copy, Check, ClipboardCopy } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import { fetchTTS, getToken } from "@/lib/api";
import { useProfile } from "@/hooks/useProfile";

// ─── Model metadata ────────────────────────────────────────
const MODEL_META: Record<string, { displayName: string; avatar: string; color: string }> = {
  "syn-v1-free": {
    displayName: "LUCIAN Llama 4 Scout",
    avatar: "/syn-v1-free.png",
    color: "hsl(0 0% 60%)",
  },
  "syn-v1-mistral": {
    displayName: "LUCIAN GPT-OSS 120B",
    avatar: "/syn-v1-pro.png",
    color: "hsl(0 0% 80%)",
  },
  "syn-v1-gemma": {
    displayName: "LUCIAN Qwen3 32B",
    avatar: "/syn-v1-qwen.png",
    color: "hsl(220 80% 65%)",
  },
  "syn-v1-qwen": {
    displayName: "LUCIAN GPT-OSS 20B",
    avatar: "/syn-v1-pro.png",
    color: "hsl(210 70% 65%)",
  },
  "syn-v1-nemotron": {
    displayName: "LUCIAN Llama 3.3 70B",
    avatar: "/syn-v1-llama.png",
    color: "hsl(142 70% 40%)",
  },
  "syn-v1-deepseek": {
    displayName: "LUCIAN Llama 3.1 8B",
    avatar: "/syn-v1-free.png",
    color: "hsl(0 0% 50%)",
  },
  "syn-v1-gemini": {
    displayName: "LUCIAN-GEMINI-3.5",
    avatar: "/syn-v1-gemini.png",
    color: "hsl(210 80% 60%)",
  },
  "syn-v1-openfable": {
    displayName: "OPENFABLE",
    avatar: "/openfable.png",
    color: "hsl(270 70% 65%)",
  },
};

const DEFAULT_MODEL = "syn-v1-openfable";

// ─── Rehype plugin: wrap each word in a span so newly streamed
// words fade in smoothly. Skips code, pre and KaTeX math nodes.
type HastNode = {
  type: string;
  tagName?: string;
  value?: string;
  properties?: { className?: string[] | string };
  children?: HastNode[];
};

const hasClass = (node: HastNode, name: string) => {
  const cn = node.properties?.className;
  if (!cn) return false;
  return Array.isArray(cn) ? cn.includes(name) : String(cn).includes(name);
};

const rehypeWordFade = () => (tree: HastNode) => {
  const visit = (node: HastNode) => {
    if (!node.children) return;
    // Don't touch code blocks or rendered math
    if (
      node.tagName === "code" ||
      node.tagName === "pre" ||
      hasClass(node, "katex") ||
      hasClass(node, "math")
    ) {
      return;
    }

    const newChildren: HastNode[] = [];
    for (const child of node.children) {
      if (child.type === "text" && typeof child.value === "string") {
        const parts = child.value.split(/(\s+)/);
        for (const part of parts) {
          if (part === "") continue;
          if (/^\s+$/.test(part)) {
            newChildren.push({ type: "text", value: part });
          } else {
            newChildren.push({
              type: "element",
              tagName: "span",
              properties: { className: ["fade-word"] },
              children: [{ type: "text", value: part }],
            });
          }
        }
      } else {
        visit(child);
        newChildren.push(child);
      }
    }
    node.children = newChildren;
  };
  visit(tree);
};

// ─── CodeBlock ────────────────────────────────────────
const CodeBlock = ({ children, className }: { children: string; className?: string }) => {
  const [copied, setCopied] = useState(false);
  const lang = className?.replace("language-", "") || "";

  const handleCopy = () => {
    navigator.clipboard.writeText(children.replace(/\n$/, ""));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="code-block-wrapper">
      <div className="code-block-header">
        <span className="code-block-lang">{lang}</span>
        <button onClick={handleCopy} className="code-copy-btn">
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre><code className={className}>{children}</code></pre>
    </div>
  );
};

// ─── Model Avatar ────────────────────────────────────────
const ModelAvatar = ({ modelSlug }: { modelSlug: string }) => {
  const meta = MODEL_META[modelSlug] ?? MODEL_META[DEFAULT_MODEL];
  const [imgError, setImgError] = useState(false);

  return (
    <div
      style={{
        width: 26,
        height: 26,
        borderRadius: "50%",
        overflow: "hidden",
        background: "hsl(0 0% 10%)",
        border: "1px solid rgba(255,255,255,0.1)",
        flexShrink: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "0.6rem",
        fontWeight: 700,
        color: meta.color,
        fontFamily: "'JetBrains Mono', monospace",
      }}
    >
      {!imgError ? (
        <img
          src={meta.avatar}
          alt={meta.displayName}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
          onError={() => setImgError(true)}
        />
      ) : (
        meta.displayName.slice(0, 2)
      )}
    </div>
  );
};

// MessageBubble 

interface MessageBubbleProps {
  role: "user" | "assistant";
  content: string;
  thinking?: string;
  imagePreview?: string;
  imageGenerated?: string;
  onPlayRequest?: (play: () => Promise<void>, pause: () => void) => void;
  modelSlug?: string;
  ttft_ms?: number;
  /** When true, AI text is currently streaming — newly arriving words fade in. */
  isStreaming?: boolean;
}

const MessageBubble = ({
  role,
  content,
  thinking,
  imagePreview,
  imageGenerated,
  onPlayRequest,
  modelSlug = DEFAULT_MODEL,
  ttft_ms,
  isStreaming = false,
}: MessageBubbleProps) => {
  const { profile } = useProfile();
  const [ttsState, setTtsState] = useState<"idle" | "loading" | "playing">("idle");
  const [showThinking, setShowThinking] = useState(false);
  const [copiedResponse, setCopiedResponse] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const urlRef = useRef<string | null>(null);

  const modelMeta = MODEL_META[modelSlug] ?? MODEL_META[DEFAULT_MODEL];

  const pause = useCallback(() => {
    audioRef.current?.pause();
    setTtsState("idle");
  }, []);

  const play = useCallback(async () => {
    const token = getToken();
    if (!token) return;
    setTtsState("loading");
    try {
      const blob = await fetchTTS(token, content);
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
      const url = URL.createObjectURL(blob);
      urlRef.current = url;
      const audio = new Audio(url);
      audioRef.current = audio;
      audio.onended = () => setTtsState("idle");
      audio.onerror = () => setTtsState("idle");
      await audio.play();
      setTtsState("playing");
    } catch {
      setTtsState("idle");
    }
  }, [content]);

  const handleTTSClick = () => {
    if (ttsState === "playing") { pause(); return; }
    if (ttsState === "loading") return;
    onPlayRequest?.(play, pause);
  };

  // ─── User bubble ────────────────────────────────────────
  if (role === "user") {
    return (
      <div className="msg-user-row">
        <div className="msg-user-bubble">
          {imagePreview && (
            <img src={imagePreview} alt="Sent image" className="msg-user-image" />
          )}
          {content && <span>{content}</span>}
        </div>

        <div
          style={{
            width: 26,
            height: 26,
            borderRadius: "50%",
            overflow: "hidden",
            background: "hsl(0 0% 10%)",
            border: "1px solid rgba(255,255,255,0.1)",
            flexShrink: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: "0.65rem",
            fontWeight: 700,
            color: "#666",
            alignSelf: "flex-end",
            marginBottom: 2,
          }}
        >
          {profile.avatarUrl ? (
            <img
              src={profile.avatarUrl}
              alt="you"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          ) : (
            profile.name.charAt(0).toUpperCase()
          )}
        </div>
      </div>
    );
  }

  // Assistant bubble
  return (
    <div className="group msg-assistant-row">
      <div className="msg-assistant-content">
        <div style={{ display: "flex", alignItems: "center", gap: "7px", marginBottom: "6px" }}>
          <ModelAvatar modelSlug={modelSlug} />
          <span
            style={{
              fontSize: "0.68rem",
              fontFamily: "'JetBrains Mono', monospace",
              letterSpacing: "0.06em",
              textTransform: "uppercase",
              color: "#666",
              fontWeight: 600,
              userSelect: "none",
            }}
          >
            {modelMeta.displayName}
          </span>
        </div>

        {thinking && (
          <div>
            <button onClick={() => setShowThinking(!showThinking)} className="msg-thinking-btn">
              <Brain className="w-3 h-3" />
              {showThinking ? "Hide thought" : "See thought"}
              {showThinking ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            {showThinking && (
              <div className="msg-thinking-block">
                <div style={{
                  fontSize: "0.8rem",
                  lineHeight: "1.4",
                  color: "#888",
                  whiteSpace: "pre-wrap",
                  wordBreak: "break-word",
                  fontFamily: "'JetBrains Mono', monospace",
                  padding: "8px",
                  backgroundColor: "rgba(100, 150, 255, 0.05)",
                  borderLeft: "2px solid rgba(100, 150, 255, 0.3)",
                  borderRadius: "4px",
                  marginTop: "6px",
                }}>
                  {thinking}
                </div>
              </div>
            )}
          </div>
        )}

        <div className="msg-assistant-text prose-chat">
          <ReactMarkdown
            remarkPlugins={[remarkGfm, remarkMath]}
            rehypePlugins={isStreaming ? [rehypeKatex, rehypeWordFade] : [rehypeKatex]}
            components={{
              code({ className, children, ...props }) {
                const text = String(children);
                const isBlock = className || text.includes("\n");
                if (isBlock) {
                  return <CodeBlock className={className}>{text}</CodeBlock>;
                }
                return <code className={className} {...props}>{children}</code>;
              },
              pre({ children }) {
                return <>{children}</>;
              },
            }}
          >
            {content}
          </ReactMarkdown>
          {imageGenerated && (
            <div className="msg-generated-image-wrapper">
              <img
                src={imageGenerated}
                alt="Imagem gerada"
                className="msg-generated-image"
                loading="lazy"
                title="Clique para baixar"
                style={{ cursor: "pointer" }}
                onClick={async () => {
                  try {
                    const res = await fetch(imageGenerated);
                    const blob = await res.blob();
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = `lucian-image-${Date.now()}.png`;
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                    setTimeout(() => URL.revokeObjectURL(url), 5000);
                  } catch {
                    window.open(imageGenerated, "_blank");
                  }
                }}
              />
            </div>
          )}
        </div>
      </div>

      {ttft_ms !== undefined && (
        <div style={{
          fontSize: "0.62rem",
          color: "#555",
          opacity: 0.5,
          marginTop: "4px",
          marginLeft: "33px",
          fontFamily: "'JetBrains Mono', monospace",
          letterSpacing: "0.03em",
          userSelect: "none",
        }}>
          ⚡ {ttft_ms}ms
        </div>
      )}
      <div className="msg-action-buttons">
        <button
          onClick={() => {
            navigator.clipboard.writeText(content);
            setCopiedResponse(true);
            setTimeout(() => setCopiedResponse(false), 2000);
          }}
          className="msg-tts-btn"
          title="Copy response"
        >
          {copiedResponse ? <Check className="w-4 h-4" /> : <ClipboardCopy className="w-4 h-4" />}
        </button>
        <button onClick={handleTTSClick} className="msg-tts-btn" title="Listen to response">
          {ttsState === "loading" && <Loader2 className="w-4 h-4 animate-spin" />}
          {ttsState === "playing" && <Pause className="w-4 h-4" />}
          {ttsState === "idle" && <Volume2 className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};

export default MessageBubble;
