import { useState, useRef, useEffect } from "react";
import { Menu, Github, Settings, LogOut, MoreHorizontal, ChevronDown, Check } from "lucide-react";
import { API_URL, getToken } from "@/lib/api";
import { useNavigate } from "react-router-dom";
import { MODELS, getModelLabel } from "@/lib/models";
import { getUserPlan } from "@/lib/auth";
import { createCheckoutSession } from "@/lib/api";

interface HeaderProps {
  remainingTokens?: number | null;
  tokensUsed?: number | null;
  onLogout: () => void;
  onSidebarToggle?: () => void;
  isGuest?: boolean;
  selectedModel?: string;
  onModelChange?: (model: string) => void;
}

const Header = ({
  remainingTokens,
  tokensUsed,
  onLogout,
  onSidebarToggle,
  isGuest,
  selectedModel = "syn-v1-free",
  onModelChange,
}: HeaderProps) => {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [modelOpen, setModelOpen] = useState(false);
  const [githubUsername, setGithubUsername] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const modelRef = useRef<HTMLDivElement>(null);
  const userPlan = getUserPlan();

  useEffect(() => {
    const token = getToken();
    if (token) {
      fetch(`${API_URL}/auth/github/status`, {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((r) => r.json())
        .then((d) => { if (d.connected) setGithubUsername(d.username); })
        .catch(() => {});
    }
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
      if (modelRef.current && !modelRef.current.contains(e.target as Node)) setModelOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleConnectGitHub = async () => {
    const token = getToken();
    if (!token) return;
    const res = await fetch(`${API_URL}/auth/github`, { headers: { Authorization: `Bearer ${token}` } });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
  };

  const handleDisconnectGitHub = async () => {
    if (!confirm("Disconnect your GitHub account?")) return;
    const token = getToken();
    if (!token) return;
    await fetch(`${API_URL}/auth/github/disconnect`, { method: "POST", headers: { Authorization: `Bearer ${token}` } });
    setGithubUsername(null);
  };

  const handleLogout = () => {
    localStorage.removeItem("sof_token");
    setMenuOpen(false);
    onLogout();
  };

  const handleLockedModelClick = async () => {
    setModelOpen(false);
    const token = getToken();
    if (!token) return;
    try {
      const { url } = await createCheckoutSession(token);
      window.location.href = url;
    } catch {
      window.location.href = "/";
    }
  };

  return (
    <>
      <header className="header-bar">
        <div className="header-gradient" />

        <div className="header-inner" style={{ position: "relative" }}>
          {/* ── Left: sidebar toggle ── */}
          <div className="header-left" style={{ minWidth: 44 }}>
            {!isGuest && onSidebarToggle && (
              <button
                onClick={onSidebarToggle}
                className="header-icon-btn"
                aria-label="Open history"
              >
                <Menu className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* ── Center: model selector ── */}
          <div
            ref={modelRef}
            style={{
              position: "absolute",
              left: "50%",
              transform: "translateX(-50%)",
              zIndex: 10,
            }}
          >
            <button
              onClick={() => setModelOpen((o) => !o)}
              className="header-model-btn"
              style={{
                gap: 5,
                paddingLeft: 14,
                paddingRight: 12,
                fontFamily: "'ClashDisplay-Variable', 'Clash Display', 'Inter', sans-serif",
                fontWeight: 500,
                fontSize: "0.8rem",
                textTransform: "none",
                letterSpacing: "-0.01em",
                color: "hsl(0 0% 75%)",
              }}
            >
              <span>{getModelLabel(selectedModel)}</span>
              <ChevronDown
                className="w-3 h-3"
                style={{
                  opacity: 0.6,
                  transition: "transform 180ms ease",
                  transform: modelOpen ? "rotate(180deg)" : "rotate(0deg)",
                }}
              />
            </button>

            {modelOpen && (
              <div
                className="header-dropdown"
                style={{ top: "calc(100% + 8px)", minWidth: 220 }}
              >
                {MODELS.map((model) => {
                  const locked = model.proOnly && userPlan !== "paid";
                  const active = selectedModel === model.slug;
                  return (
                    <button
                      key={model.slug}
                      className="header-dropdown-item"
                      onClick={() => {
                        if (locked) {
                          handleLockedModelClick();
                        } else {
                          onModelChange?.(model.slug);
                          setModelOpen(false);
                        }
                      }}
                      style={{
                        color: active ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground))",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        opacity: locked ? 0.6 : 1,
                      }}
                    >
                      <div style={{ display: "flex", flexDirection: "column", gap: 1, alignItems: "flex-start" }}>
                        <span style={{ fontWeight: 600 }}>{model.label}</span>
                        <span style={{ fontSize: "0.67rem", opacity: 0.6 }}>{model.desc}</span>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        {model.proOnly && (
                          <span style={{ fontSize: "0.65rem", fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", color: "hsl(43 96% 66%)" }}>
                            ✦ Pro
                          </span>
                        )}
                        {active && <Check className="w-3 h-3" />}
                      </div>
                    </button>
                  );
                })}
                {(remainingTokens !== null && remainingTokens !== undefined) && (
                  <div className="header-remaining">
                    <span className="header-tokens-used">{tokensUsed || 0}</span>
                    <span className="header-tokens-sep"> / </span>
                    <span className="header-tokens-total">{remainingTokens + (tokensUsed || 0)}</span>
                    <span className="header-tokens-label"> tokens used</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ── Right: user menu ── */}
          <div className="header-actions" style={{ minWidth: 44, justifyContent: "flex-end" }}>
            <div ref={menuRef} className="relative">
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="header-icon-btn"
                aria-label="Menu"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>

              {menuOpen && (
                <div
                  className="header-dropdown"
                  style={{ right: 0, left: "auto", top: "calc(100% + 8px)" }}
                >
                  {!isGuest && (
                    <button
                      onClick={() => { setMenuOpen(false); navigate("/settings/customization"); }}
                      className="header-dropdown-item"
                    >
                      <Settings className="w-3 h-3" />
                      Customization
                    </button>
                  )}

                  {githubUsername ? (
                    <button onClick={handleDisconnectGitHub} className="header-dropdown-item">
                      <Github className="w-3 h-3" />
                      GitHub: @{githubUsername}
                    </button>
                  ) : (
                    <button onClick={handleConnectGitHub} className="header-dropdown-item">
                      <Github className="w-3 h-3" />
                      Connect GitHub
                    </button>
                  )}

                  <button
                    onClick={() => { setMenuOpen(false); navigate("/settings"); }}
                    className="header-dropdown-item"
                  >
                    <Settings className="w-3 h-3" />
                    Settings
                  </button>

                  <button onClick={handleLogout} className="header-dropdown-item" style={{ color: "hsl(var(--muted-foreground))" }}>
                    <LogOut className="w-3 h-3" />
                    Log out
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>
    </>
  );
};

export default Header;
