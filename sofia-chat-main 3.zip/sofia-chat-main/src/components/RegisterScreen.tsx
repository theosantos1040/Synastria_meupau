import { useState, FormEvent, useEffect } from "react";
import { API_URL, registerHeaders } from "@/lib/api";
import { sendOTP, verifyOTP } from "@/lib/email";
import StarLogo from "./StarLogo";
import { motion, AnimatePresence } from "framer-motion";
import { Github } from "lucide-react";

interface RegisterScreenProps {
  onLogin: (token: string) => void;
  onSwitchToLogin: () => void;
}

type Step = "register" | "verify";

const RegisterScreen = ({ onLogin, onSwitchToLogin }: RegisterScreenProps) => {
  const [step, setStep] = useState<Step>("register");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [pendingToken, setPendingToken] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  // Countdown para reenvio
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const t = setTimeout(() => setResendCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [resendCooldown]);

  const validatePassword = (pwd: string): string | null => {
    if (pwd.length < 8) return "Password needs at least 8 characters.";
    if (!/[A-Z]/.test(pwd)) return "Password needs a capital letter.";
    if (!/[0-9]/.test(pwd)) return "Password needs a number.";
    return null;
  };

  // Step 1 — Registro
  const handleRegister = async (e: FormEvent) => {
    e.preventDefault();
    if (!email || !password || !confirmPassword) return;

    const pwdError = validatePassword(password);
    if (pwdError) { setError(pwdError); return; }

    if (password !== confirmPassword) {
      setError("Passwords don't match.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res = await fetch(`/api/register`, {
        method: "POST",
        headers: registerHeaders(),
        body: JSON.stringify({ email, password }),
      });

      if (res.status === 409) { setError("This email is already in use."); return; }
      if (!res.ok) { setError("Error creating account. Please try again."); return; }

      const data = await res.json();
      setPendingToken(data.token);

      // Envia OTP de verificação via Resend
      await sendOTP(email, "email_verification");
      setStep("verify");
      setResendCooldown(60);
    } catch (err) {
      setError(err instanceof Error ? err.message : "API error, try again.");
    } finally {
      setLoading(false);
    }
  };

  // Step 2 — Verificação OTP
  const handleVerify = async (e: FormEvent) => {
    e.preventDefault();
    if (!otp || otp.length !== 6) { setError("Enter the 6-digit code."); return; }

    setLoading(true);
    setError("");

    try {
      await verifyOTP(email, otp, "email_verification");
      if (pendingToken) {
        localStorage.setItem("sof_token", pendingToken);
        onLogin(pendingToken);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid code.");
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (resendCooldown > 0) return;
    setError("");
    try {
      await sendOTP(email, "email_verification");
      setResendCooldown(60);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to resend.");
    }
  };

  // GitHub OAuth (mantido igual)
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tokenFromUrl = urlParams.get("token");
    const errorFromUrl = urlParams.get("error");
    if (tokenFromUrl) {
      localStorage.setItem("sof_token", tokenFromUrl);
      onLogin(tokenFromUrl);
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (errorFromUrl) {
      setError(`GitHub register failed: ${errorFromUrl.replace(/_/g, " ")}`);
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [onLogin]);

  const handleGithubRegister = async () => {
    try {
      setLoading(true);
      setError("");
      const res = await fetch(`${API_URL}/auth/github?state=register_request`);
      const data = await res.json();
      if (data.redirect_url) {
        window.location.href = data.redirect_url;
      } else {
        setError("Could not initialize GitHub register.");
      }
    } catch {
      setError("API error. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-screen">
      <AnimatePresence mode="wait">
        {step === "register" ? (
          <motion.form
            key="register"
            onSubmit={handleRegister}
            className="auth-form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
          >
            <div className="auth-card">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="hero-glow" style={{ width: 140, height: 140 }} />
                  <StarLogo className="w-14 h-14 relative z-10" />
                </div>
              </div>
              <h1 className="auth-title">Create account</h1>
              <p className="auth-subtitle">Start using Lucian now</p>

              <div className="flex flex-col gap-3 mt-4">
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email" autoComplete="email" className="auth-input" />
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password" autoComplete="new-password" className="auth-input" />
                <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm password" autoComplete="new-password" className="auth-input" />

                <p className="auth-hint">min 8 chars · 1 uppercase · 1 number</p>

                {error && <p className="auth-error">{error}</p>}

                <button type="submit" disabled={loading} className="auth-submit">
                  {loading ? "Creating account…" : "Create account"}
                </button>

                <div className="auth-divider">or</div>

                <button type="button" onClick={handleGithubRegister} className="auth-github">
                  <Github className="w-5 h-5" />
                  Register with GitHub
                </button>
              </div>

              <p className="auth-footer">
                Already registered?{" "}
                <button type="button" onClick={onSwitchToLogin} className="auth-footer-link">Log in</button>
              </p>
            </div>
          </motion.form>
        ) : (
          <motion.form
            key="verify"
            onSubmit={handleVerify}
            className="auth-form"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
          >
            <div className="auth-card">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="hero-glow" style={{ width: 140, height: 140 }} />
                  <StarLogo className="w-14 h-14 relative z-10" />
                </div>
              </div>
              <h1 className="auth-title">Verify your email</h1>
              <p className="auth-subtitle">
                We sent a 6-digit code to <strong>{email}</strong>
              </p>

              <div className="flex flex-col gap-3 mt-4">
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                  placeholder="000000"
                  className="auth-input text-center tracking-widest text-xl"
                  autoFocus
                />

                {error && <p className="auth-error">{error}</p>}

                <button type="submit" disabled={loading} className="auth-submit">
                  {loading ? "Verifying…" : "Verify & continue"}
                </button>

                <button
                  type="button"
                  onClick={handleResend}
                  disabled={resendCooldown > 0}
                  className="auth-footer-link text-sm text-center"
                  style={{ opacity: resendCooldown > 0 ? 0.5 : 1 }}
                >
                  {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : "Resend code"}
                </button>
              </div>

              <p className="auth-footer">
                <button type="button" onClick={() => { setStep("register"); setError(""); setOtp(""); }}
                  className="auth-footer-link">
                  ← Back
                </button>
              </p>
            </div>
          </motion.form>
        )}
      </AnimatePresence>
    </div>
  );
};

export default RegisterScreen;
