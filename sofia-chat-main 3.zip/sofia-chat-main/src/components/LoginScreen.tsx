import { useState, FormEvent, useEffect } from "react";
import { API_URL } from "@/lib/api";
import { sendOTP, verifyOTP } from "@/lib/email";
import StarLogo from "./StarLogo";
import { motion, AnimatePresence } from "framer-motion";
import { Github } from "lucide-react";

interface LoginScreenProps {
  onLogin: (token: string) => void;
  onSwitchToRegister: () => void;
}

type Step = "login" | "forgot-email" | "forgot-otp" | "forgot-newpass" | "forgot-done";

const LoginScreen = ({ onLogin, onSwitchToRegister }: LoginScreenProps) => {
  const [step, setStep] = useState<Step>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [forgotEmail, setForgotEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  useEffect(() => {
    if (resendCooldown <= 0) return;
    const t = setTimeout(() => setResendCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [resendCooldown]);

  // ── Login normal ──────────────────────────────────────────
  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${API_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) { setError("Incorrect email or password."); return; }
      const data = await res.json();
      localStorage.setItem("sof_token", data.token);
      onLogin(data.token);
    } catch {
      setError("API error. Try again.");
    } finally {
      setLoading(false);
    }
  };

  // ── Forgot — step 1: enviar OTP ──────────────────────────
  const handleForgotSend = async (e: FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) return;
    setLoading(true);
    setError("");
    try {
      await sendOTP(forgotEmail, "password_reset");
      setStep("forgot-otp");
      setResendCooldown(60);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to send code.");
    } finally {
      setLoading(false);
    }
  };

  // ── Forgot — step 2: verificar OTP ───────────────────────
  const handleForgotVerify = async (e: FormEvent) => {
    e.preventDefault();
    if (!otp || otp.length !== 6) { setError("Enter the 6-digit code."); return; }
    setLoading(true);
    setError("");
    try {
      await verifyOTP(forgotEmail, otp, "password_reset");
      setStep("forgot-newpass");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid code.");
    } finally {
      setLoading(false);
    }
  };

  // ── Forgot — step 3: definir nova senha ──────────────────
  const handleForgotReset = async (e: FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 8) { setError("Password must be at least 8 characters."); return; }
    if (newPassword !== confirmNewPassword) { setError("Passwords don't match."); return; }
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`${API_URL}/auth/reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: forgotEmail, otp, new_password: newPassword }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError((data as { error?: string }).error || "Failed to reset password.");
        return;
      }
      setStep("forgot-done");
    } catch {
      setError("API error. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (resendCooldown > 0) return;
    setError("");
    try {
      await sendOTP(forgotEmail, "password_reset");
      setResendCooldown(60);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to resend.");
    }
  };

  // ── GitHub OAuth ─────────────────────────────────────────
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tokenFromUrl = urlParams.get("token");
    const errorFromUrl = urlParams.get("error");
    if (tokenFromUrl) {
      localStorage.setItem("sof_token", tokenFromUrl);
      onLogin(tokenFromUrl);
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (errorFromUrl) {
      setError(`GitHub login failed: ${errorFromUrl.replace(/_/g, " ")}`);
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [onLogin]);

  const handleGithubLogin = async () => {
    try {
      setLoading(true);
      setError("");
      const res = await fetch(`${API_URL}/auth/github?state=login_request`);
      const data = await res.json();
      if (data.redirect_url) {
        window.location.href = data.redirect_url;
      } else {
        setError("Could not initialize GitHub login.");
      }
    } catch {
      setError("API error. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const goBackToLogin = () => {
    setStep("login");
    setError("");
    setOtp("");
    setForgotEmail("");
    setNewPassword("");
    setConfirmNewPassword("");
  };

  const cardVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -16 },
  };
  const transition = { duration: 0.35, ease: "easeOut" as const };

  return (
    <div className="auth-screen">
      <AnimatePresence mode="wait">

        {/* ── LOGIN ── */}
        {step === "login" && (
          <motion.form key="login" onSubmit={handleLogin} className="auth-form"
            variants={cardVariants} initial="initial" animate="animate" exit="exit" transition={transition}>
            <div className="auth-card">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="hero-glow" style={{ width: 140, height: 140 }} />
                  <StarLogo className="w-14 h-14 relative z-10" />
                </div>
              </div>
              <h1 className="auth-title">Hello again!</h1>
              <p className="auth-subtitle">Log in to continue</p>

              <div className="flex flex-col gap-3 mt-4">
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email" autoComplete="email" className="auth-input" />
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password" autoComplete="current-password" className="auth-input" />

                <button type="button"
                  onClick={() => { setStep("forgot-email"); setForgotEmail(email); setError(""); }}
                  className="auth-footer-link text-sm text-right self-end">
                  Forgot password?
                </button>

                {error && <p className="auth-error">{error}</p>}

                <button type="submit" disabled={loading} className="auth-submit">
                  {loading ? "Logging in..." : "Login"}
                </button>

                <div className="auth-divider">or</div>

                <button type="button" onClick={handleGithubLogin} className="auth-github">
                  <Github className="w-5 h-5" />
                  Login with GitHub
                </button>
              </div>

              <p className="auth-footer">
                Want to create an account?{" "}
                <button type="button" onClick={onSwitchToRegister} className="auth-footer-link">
                  Create account
                </button>
              </p>
            </div>
          </motion.form>
        )}

        {/* ── FORGOT — email ── */}
        {step === "forgot-email" && (
          <motion.form key="forgot-email" onSubmit={handleForgotSend} className="auth-form"
            variants={cardVariants} initial="initial" animate="animate" exit="exit" transition={transition}>
            <div className="auth-card">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="hero-glow" style={{ width: 140, height: 140 }} />
                  <StarLogo className="w-14 h-14 relative z-10" />
                </div>
              </div>
              <h1 className="auth-title">Reset password</h1>
              <p className="auth-subtitle">We'll send a verification code to your email</p>

              <div className="flex flex-col gap-3 mt-4">
                <input type="email" value={forgotEmail} onChange={(e) => setForgotEmail(e.target.value)}
                  placeholder="Email" autoComplete="email" className="auth-input" autoFocus />

                {error && <p className="auth-error">{error}</p>}

                <button type="submit" disabled={loading} className="auth-submit">
                  {loading ? "Sending…" : "Send code"}
                </button>
              </div>

              <p className="auth-footer">
                <button type="button" onClick={goBackToLogin} className="auth-footer-link">← Back to login</button>
              </p>
            </div>
          </motion.form>
        )}

        {/* ── FORGOT — OTP ── */}
        {step === "forgot-otp" && (
          <motion.form key="forgot-otp" onSubmit={handleForgotVerify} className="auth-form"
            variants={cardVariants} initial="initial" animate="animate" exit="exit" transition={transition}>
            <div className="auth-card">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="hero-glow" style={{ width: 140, height: 140 }} />
                  <StarLogo className="w-14 h-14 relative z-10" />
                </div>
              </div>
              <h1 className="auth-title">Check your email</h1>
              <p className="auth-subtitle">
                Code sent to <strong>{forgotEmail}</strong>
              </p>

              <div className="flex flex-col gap-3 mt-4">
                <input type="text" inputMode="numeric" maxLength={6}
                  value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                  placeholder="000000"
                  className="auth-input text-center tracking-widest text-xl"
                  autoFocus />

                {error && <p className="auth-error">{error}</p>}

                <button type="submit" disabled={loading} className="auth-submit">
                  {loading ? "Verifying…" : "Verify code"}
                </button>

                <button type="button" onClick={handleResend} disabled={resendCooldown > 0}
                  className="auth-footer-link text-sm text-center"
                  style={{ opacity: resendCooldown > 0 ? 0.5 : 1 }}>
                  {resendCooldown > 0 ? `Resend in ${resendCooldown}s` : "Resend code"}
                </button>
              </div>

              <p className="auth-footer">
                <button type="button"
                  onClick={() => { setStep("forgot-email"); setError(""); setOtp(""); }}
                  className="auth-footer-link">← Back</button>
              </p>
            </div>
          </motion.form>
        )}

        {/* ── FORGOT — nova senha ── */}
        {step === "forgot-newpass" && (
          <motion.form key="forgot-newpass" onSubmit={handleForgotReset} className="auth-form"
            variants={cardVariants} initial="initial" animate="animate" exit="exit" transition={transition}>
            <div className="auth-card">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="hero-glow" style={{ width: 140, height: 140 }} />
                  <StarLogo className="w-14 h-14 relative z-10" />
                </div>
              </div>
              <h1 className="auth-title">New password</h1>
              <p className="auth-subtitle">Choose a strong password for your account</p>

              <div className="flex flex-col gap-3 mt-4">
                <input type="password" value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="New password" autoComplete="new-password"
                  className="auth-input" autoFocus />
                <input type="password" value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  placeholder="Confirm new password" autoComplete="new-password"
                  className="auth-input" />

                <p className="auth-hint">min 8 characters</p>

                {error && <p className="auth-error">{error}</p>}

                <button type="submit" disabled={loading} className="auth-submit">
                  {loading ? "Saving…" : "Save new password"}
                </button>
              </div>
            </div>
          </motion.form>
        )}

        {/* ── FORGOT — done ── */}
        {step === "forgot-done" && (
          <motion.div key="forgot-done" className="auth-form"
            variants={cardVariants} initial="initial" animate="animate" exit="exit" transition={transition}>
            <div className="auth-card text-center">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <div className="hero-glow" style={{ width: 140, height: 140 }} />
                  <StarLogo className="w-14 h-14 relative z-10" />
                </div>
              </div>
              <h1 className="auth-title">Password updated!</h1>
              <p className="auth-subtitle">Your password has been reset. You can now log in.</p>
              <button type="button" onClick={goBackToLogin} className="auth-submit mt-6">
                Back to login
              </button>
            </div>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
};

export default LoginScreen;
